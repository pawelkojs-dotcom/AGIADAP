# Phase 0 Theory Validation - HYBRID PACKAGE

## 📦 Complete Package

**Approach:** Hybrid (GPT Philosophy + Claude Depth + GPT Formalism)

---

## Package Contents

### Documentation (3 files)
✅ `MANIFEST.md` - This file  
✅ `00_README_PHASE0.md` - Phase 0 guide (hybrid)  
✅ `theory/MATHEMATICAL_FOUNDATIONS.md` - Formal proofs (GPT)

### Test Files (4 files)
✅ `test_axioms.py` - Level 0 (GPT simple)  
✅ `test_fidelity.py` - Level 1 (GPT simple)  
✅ `test_scaling.py` - Level 2 (Claude RG)  
✅ `test_topology.py` - Level 3 (Claude Morse)

### Infrastructure (3 files)
✅ `__init__.py` - Package marker  
✅ `run_full_validation.sh` - Runner script  
✅ `visualizations/plot_phase_diagrams.py` - Plots

### Total
**10 files, ~2000 lines of code + documentation**

---

## 📁 File Structure

```
phase0_hybrid/
├── MANIFEST.md                              # This file
└── experiments/
    └── theory_validation/
        ├── 00_README_PHASE0.md             # Main documentation
        ├── __init__.py                     # Package marker
        ├── test_axioms.py                  # Level 0: GPT simple
        ├── test_fidelity.py                # Level 1: GPT simple
        ├── test_scaling.py                 # Level 2: Claude RG
        ├── test_topology.py                # Level 3: Claude Morse
        ├── run_full_validation.sh          # Runner script
        ├── results/                        # Test outputs
        ├── theory/
        │   └── MATHEMATICAL_FOUNDATIONS.md # GPT formalism (P2/P4)
        └── visualizations/
            └── plot_phase_diagrams.py      # Plots
```

---

## 🎯 Hybrid Approach

### What Makes This "Hybrid"?

**From GPT Wątek 1 (Simple Tests):**
- `test_axioms.py` - Clean, minimal, CI/CD-friendly
- `test_fidelity.py` - Practical, straightforward validation
- **Philosophy:** Engineering practicality

**From Claude (Physics-Grade):**
- `test_scaling.py` - RG analysis (Kadanoff, critical phenomena)
- `test_topology.py` - Morse theory, basin structure
- `visualizations/` - Publication-quality plots
- **Philosophy:** Research depth

**From GPT Wątek 2 (Mathematical Formalism):**
- `theory/MATHEMATICAL_FOUNDATIONS.md` - Formal proofs of P2/P4
- Gradient flow analysis, Lyapunov theory
- Optimal Θ derivation ("inverted-U")
- **Philosophy:** Publication rigor

### Why Hybrid?

| Need | GPT Simple | Claude Physics | GPT Formalism | Hybrid |
|------|-----------|----------------|---------------|--------|
| CI/CD speed | ✅ | ❌ | N/A | ✅ |
| RG analysis | ❌ | ✅ | ⚠️ Theory only | ✅ |
| Morse topology | ❌ | ✅ | ❌ | ✅ |
| P2/P4 proofs | ❌ | ⚠️ Qualitative | ✅ Rigorous | ✅ |
| Publications | ❌ | ⚠️ Partial | ✅ | ✅ |

**Result:** Best of all three worlds.

---

## 🚀 Quick Start

### Step 1: Extract Archive

```bash
tar -xzf phase0_hybrid.tar.gz
cd phase0_hybrid
```

### Step 2: Copy to Project

```bash
cp -r experiments/ /your/adaptonic/project/
```

### Step 3: Run Fast Tests (30 seconds)

```bash
cd /your/adaptonic/project

# Level 0+1 (GPT simple)
pytest experiments/theory_validation/test_axioms.py -v
pytest experiments/theory_validation/test_fidelity.py -v
```

### Step 4: Full Validation (8 minutes)

```bash
# All levels
./experiments/theory_validation/run_full_validation.sh

# Results
ls experiments/theory_validation/results/
```

### Step 5: Read Theory

```bash
# Mathematical foundations
cat experiments/theory_validation/theory/MATHEMATICAL_FOUNDATIONS.md
```

---

## 📊 What Each Level Tests

### Level 0: Axioms (< 5s) - GPT Simple
**Purpose:** Catch obvious bugs  
**Tests:** Bounds [0,1], no NaN/Inf  
**Style:** Minimal, CI/CD-friendly

```python
def test_sigma_in_unit_interval():
    X = rng.normal(size=(200, 64))
    sigma = compute_sigma_spectral(X)
    assert 0.0 <= sigma <= 1.0
```

---

### Level 1: Fidelity (< 30s) - GPT Simple
**Purpose:** Verify implementation matches KERNEL  
**Tests:** Limits, monotonicity, invariances  
**Style:** Practical, straightforward

```python
def test_perfect_order_limit():
    # Perfect order: σ → 1
    v = rng.normal(size=64)
    X = np.tile(v, (20, 1))
    sigma = compute_sigma_spectral(X, k=16)
    assert sigma > 0.95
```

---

### Level 2: Scaling (< 2min) - Claude RG
**Purpose:** RG properties, critical phenomena  
**Tests:** Finite-size, coarse-graining, critical exponents  
**Style:** Physics-grade (Kadanoff)

```python
def test_sigma_saturation_with_N():
    """σ(N) → σ_∞ as N → ∞"""
    N_values = [10, 20, 40, 80, 160]
    # Test saturation and convergence
```

---

### Level 3: Topology (< 5min) - Claude Morse
**Purpose:** Global F landscape structure  
**Tests:** Critical points, basins, gradient flow  
**Style:** Differential topology

```python
def test_critical_points_classification():
    """Find and classify critical points of F(E, Θ, S)"""
    # Morse theory analysis
```

---

### Theory: Mathematical Foundations - GPT Formalism
**Purpose:** Formal proofs of core theorems  
**Content:** P2 (gradient flow), P4 (optimal Θ)  
**Style:** Publication-ready

**Theorem P2:**
```
γ·σ̇(t) = −∇F(σ(t); Θ)
⇒ σ(t) → σ* (unique, stable)
⇒ F(t) Lyapunov (monotone decreasing)
```

**Theorem P4:**
```
F(σ; Θ) = E_0(σ) + α·Θ² − Θ·S(σ)
⇒ Θ*(σ) = S(σ)/(2α)
⇒ "Inverted-U" for Θ
```

---

## 🎯 Decision Gate 1

### ✅ GO to Phase 1 (H_GEN_1) if:
- All Level 0-1 tests pass (required)
- Level 2 shows σ, S, Θ scale correctly (< 10% drift)
- Level 3 confirms F has single minimum at low E

### ⚠️ REVIEW if:
- Level 2-3 show unexpected behavior
- Computational complexity > expected
- Any Crisis #1-4 symptoms

### ❌ NO-GO (fix implementation) if:
- Any Level 0-1 test fails
- Metrics violate basic axioms
- NaN/Inf in normal operation

---

## 📚 Documentation Hierarchy

```
00_README_PHASE0.md              # Start here - overview
    ↓
theory/MATHEMATICAL_FOUNDATIONS.md   # Deep theory
    ↓
test_*.py                        # Implementation
    ↓
MANIFEST.md                      # This file - usage
```

---

## 🔧 Requirements

**Python packages:**
```bash
pip install numpy scipy matplotlib pytest
```

**Your implementation:**
```bash
pip install -e /path/to/adaptonic_metrics
```

Or add to PYTHONPATH:
```bash
export PYTHONPATH=$PYTHONPATH:/path/to/adaptonic_metrics
```

---

## 📖 Integration Guide

### Add to CI/CD

```yaml
# .github/workflows/test.yml
- name: Phase 0 Validation
  run: |
    pytest experiments/theory_validation/test_axioms.py -v
    pytest experiments/theory_validation/test_fidelity.py -v
```

### Update Main README

Add section from `00_README_PHASE0.md` to your main project README.

### Pre-Release Checklist

- [ ] Level 0-1 all pass
- [ ] Level 2 reviewed (no >10% drift)
- [ ] Level 3 documented
- [ ] Mathematical foundations understood
- [ ] Decision Gate 1: GO/NO-GO

---

## 🐛 Troubleshooting

### Import Errors

```bash
# Error: ModuleNotFoundError: No module named 'adaptonic_metrics'
# Solution:
pip install -e /path/to/adaptonic_metrics
```

### Test Failures

```bash
# Level 0-1 fail → Fix implementation
# Level 2-3 fail → Review but may proceed
```

### Matplotlib Errors

```bash
# If display issues:
export MPLBACKEND=Agg
```

---

## 📜 Credits

### Contributors

**GPT (Wątek 1):**
- Simple test implementations (L0-1)
- Clean, practical philosophy

**Claude:**
- RG analysis (L2)
- Morse theory (L3)
- Visualizations

**GPT (Wątek 2):**
- Mathematical formalism (P2/P4)
- Gradient flow proofs
- Optimal Θ derivation

### Theory Foundation

- **KERNEL_AGI** (Paweł)
- **Wilson (1971):** RG methods
- **Landau (1937):** Phase transitions
- **Lyapunov (1892):** Stability theory
- **Morse (1925):** Topology

---

## ✅ Pre-Deployment Checklist

Before Phase 1 (H_GEN_1):

- [ ] All files copied to project
- [ ] Dependencies installed
- [ ] Level 0 tests pass (< 5s)
- [ ] Level 1 tests pass (< 30s)
- [ ] Level 2 reviewed (< 2min)
- [ ] Level 3 documented (< 5min)
- [ ] Mathematical foundations read
- [ ] Visualizations generated
- [ ] Decision Gate 1: GO documented

---

**Version:** 1.0 (Hybrid)  
**Status:** Phase 0 - Theory Validation  
**Date:** 2025-11-21  
**Approach:** GPT + Claude + GPT
