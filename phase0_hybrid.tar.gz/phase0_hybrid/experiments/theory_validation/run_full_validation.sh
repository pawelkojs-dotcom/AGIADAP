#!/bin/bash
# Complete Phase 0 validation suite (Hybrid Approach)

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║  PHASE 0: DEEP THEORY VALIDATION (HYBRID)                     ║"
echo "║  GPT Philosophy + Claude Depth + GPT Formalism                ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Set paths
VALIDATION_DIR="experiments/theory_validation"
OUTPUT_DIR="$VALIDATION_DIR/results"
mkdir -p "$OUTPUT_DIR"

echo "📋 Validation Levels:"
echo "   Level 0: Axioms (< 5s) - GPT simple"
echo "   Level 1: Fidelity (< 30s) - GPT simple"
echo "   Level 2: Scaling (< 2min) - Claude RG"
echo "   Level 3: Topology (< 5min) - Claude Morse"
echo "   Theory: Mathematical foundations - GPT formalism"
echo ""

# Run tests
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "LEVEL 0: Axioms (GPT simple)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
pytest "$VALIDATION_DIR/test_axioms.py" -v -s 2>&1 | tee "$OUTPUT_DIR/00_axioms.log"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "LEVEL 1: Fidelity (GPT simple)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
pytest "$VALIDATION_DIR/test_fidelity.py" -v -s 2>&1 | tee "$OUTPUT_DIR/01_fidelity.log"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "LEVEL 2: Scaling (Claude RG)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
pytest "$VALIDATION_DIR/test_scaling.py" -v -s 2>&1 | tee "$OUTPUT_DIR/02_scaling.log"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "LEVEL 3: Topology (Claude Morse)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
pytest "$VALIDATION_DIR/test_topology.py" -v -s 2>&1 | tee "$OUTPUT_DIR/03_topology.log"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "VISUALIZATIONS"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
cd "$VALIDATION_DIR/visualizations"
python plot_phase_diagrams.py 2>&1 | tee "../results/04_visualizations.log"
cd - > /dev/null

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║  PHASE 0 VALIDATION: COMPLETE (HYBRID)                        ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""
echo "📊 Results: $OUTPUT_DIR/"
echo "📐 Theory: $VALIDATION_DIR/theory/MATHEMATICAL_FOUNDATIONS.md"
echo ""
echo "Decision Gate 1:"
echo "  ✅ All Level 0-1 pass → Ready for H_GEN_1"
echo "  ⚠️ Level 2-3 issues → Review before deployment"
echo "  ❌ Level 0-1 fail → Fix implementation"
echo ""
echo "Approach: Hybrid (GPT simple + Claude physics + GPT formalism)"
