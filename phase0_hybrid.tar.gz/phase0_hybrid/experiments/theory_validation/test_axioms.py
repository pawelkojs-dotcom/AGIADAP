"""
Level 0 — Axiom Checks (Fast)

Sprawdza podstawowe aksjomaty i ograniczenia dla σ, Θ, S.

To są najprostsze testy, uruchamiane w CI/CD przy każdym commicie.
"""

import numpy as np

from adaptonic_metrics.core.sigma import compute_sigma_spectral
from adaptonic_metrics.core.entropy import compute_spectral_entropy
from adaptonic_metrics.core.theta import compute_theta_from_probs


def test_sigma_in_unit_interval():
    """σ musi zawsze leżeć w [0, 1]."""
    rng = np.random.default_rng(0)
    X = rng.normal(size=(200, 64))
    sigma = compute_sigma_spectral(X)
    assert 0.0 <= sigma <= 1.0, f"σ poza [0,1]: {sigma}"


def test_theta_in_unit_interval():
    """Θ (na rozkładach prawdopodobieństwa) musi leżeć w [0, 1]."""
    rng = np.random.default_rng(1)
    p = rng.uniform(size=50)
    p /= p.sum()
    theta = compute_theta_from_probs(p)
    assert 0.0 <= theta <= 1.0, f"Θ poza [0,1]: {theta}"


def test_entropy_in_unit_interval():
    """S_norm (znormalizowana entropia widmowa) musi leżeć w [0, 1]."""
    rng = np.random.default_rng(2)
    X = rng.normal(size=(300, 32))
    _, S_norm = compute_spectral_entropy(X)
    assert 0.0 <= S_norm <= 1.0, f"S_norm poza [0,1]: {S_norm}"


def test_no_nan_inf_sigma():
    """σ nie może dawać NaN/Inf dla typowych danych."""
    rng = np.random.default_rng(3)
    X = rng.normal(size=(100, 16))
    sigma = compute_sigma_spectral(X)
    assert np.isfinite(sigma), f"σ nie jest finite: {sigma}"


def test_no_nan_inf_entropy():
    """S_norm nie może dawać NaN/Inf dla typowych danych."""
    rng = np.random.default_rng(4)
    X = rng.normal(size=(150, 24))
    _, S_norm = compute_spectral_entropy(X)
    assert np.isfinite(S_norm), f"S_norm nie jest finite: {S_norm}"


def test_no_nan_inf_theta():
    """Θ nie może dawać NaN/Inf dla typowych rozkładów."""
    rng = np.random.default_rng(5)
    p = rng.uniform(size=20)
    p /= p.sum()
    theta = compute_theta_from_probs(p)
    assert np.isfinite(theta), f"Θ nie jest finite: {theta}"
