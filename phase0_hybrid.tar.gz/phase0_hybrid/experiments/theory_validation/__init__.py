"""
Phase 0: Theory Validation Suite (Hybrid Approach)

Hierarchical validation of adaptonic metrics implementation.

Levels:
0. Axioms (5s) - Basic properties (GPT simple)
1. Fidelity (30s) - KERNEL correctness (GPT simple)
2. Scaling (2min) - RG properties (Claude physics)
3. Topology (5min) - Global structure (Claude topology)

Theory: Mathematical foundations (GPT formalism)

Run: pytest experiments/theory_validation/ -v

Approach: Hybrid (GPT + Claude)
"""

__version__ = "1.0.0-hybrid"
__status__ = "Phase 0 - Theory Validation (Hybrid)"
