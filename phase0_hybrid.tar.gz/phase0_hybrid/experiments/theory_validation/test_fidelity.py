"""
Level 1 — Implementation Fidelity Tests

Sprawdza, czy implementacje metryk σ, Θ, S, F
wiernie realizują jakościowe własności teorii KERNEL_AGI.

Czas docelowy: < 30 sekund przy typowej maszynie.
"""

import numpy as np

from adaptonic_metrics.core.sigma import compute_sigma_spectral
from adaptonic_metrics.core.entropy import (
    compute_spectral_entropy,
    compute_effective_dimensionality,
)
from adaptonic_metrics.core.theta import (
    compute_theta_from_probs,
    compute_theta_output_channel,
)
from adaptonic_metrics.core.free_energy import compute_free_energy


# =============================================================================
# SIGMA — FIDELITY
# =============================================================================

class TestSigmaFidelity:
    """σ_spectral musi implementować pole σ z KERNEL_AGI."""

    def test_perfect_order_limit(self):
        """
        KERNEL:
        - jeśli wszystkie wektory są równoległe → σ → 1.
        """
        rng = np.random.default_rng(0)
        v = rng.normal(size=64)
        v /= np.linalg.norm(v) + 1e-12

        X = np.repeat(v[None, :], repeats=50, axis=0)
        X += rng.normal(size=X.shape) * 1e-6  # drobny szum

        sigma = compute_sigma_spectral(X, k=min(16, X.shape[1]))
        assert sigma > 0.95, f"Perfect order: σ={sigma:.3f} powinno być bliskie 1"

    def test_maximum_disorder_limit(self):
        """
        KERNEL:
        - jeśli wektory są niezależne/ortogonalne → σ → 0.
        """
        rng = np.random.default_rng(1)
        Q, _ = np.linalg.qr(rng.normal(size=(128, 128)))
        X = Q[:32, :]  # ~ortogonalne wektory

        sigma = compute_sigma_spectral(X, k=min(16, X.shape[1]))
        assert sigma < 0.3, f"Max disorder: σ={sigma:.3f} powinno być bliskie 0"

    def test_monotonic_with_alignment(self):
        """
        KERNEL:
        - przy zwiększaniu udziału wspólnego kierunku, σ musi rosnąć.
        """
        rng = np.random.default_rng(2)
        d, n = 64, 50
        base = rng.normal(size=d)
        base /= np.linalg.norm(base) + 1e-12

        sigmas = []
        for a in [0.0, 0.2, 0.5, 1.0, 2.0]:
            noise = rng.normal(size=(n, d))
            X = noise + a * base
            sigma = compute_sigma_spectral(X, k=min(16, d))
            sigmas.append(sigma)

        for i in range(len(sigmas) - 1):
            assert sigmas[i] <= sigmas[i + 1] + 1e-2, \
                f"σ nie rośnie monotonicznie z alignment: {sigmas}"

    def test_rotation_invariance(self):
        """
        KERNEL:
        - σ musi być niezmiennicze na transformacje ortogonalne.
        """
        rng = np.random.default_rng(3)
        X = rng.normal(size=(40, 32))
        A, _ = np.linalg.qr(rng.normal(size=(32, 32)))  # ortogonalna

        sigma1 = compute_sigma_spectral(X, k=min(16, X.shape[1]))
        sigma2 = compute_sigma_spectral(X @ A, k=min(16, X.shape[1]))

        assert abs(sigma1 - sigma2) < 1e-6, \
            f"σ nie jest rotacyjnie niezmiennicze: {sigma1:.6f} vs {sigma2:.6f}"


# =============================================================================
# THETA — FIDELITY
# =============================================================================

class TestThetaFidelity:
    """Θ musi zachowywać się jak temperatura informacyjna w sensie KERNEL."""

    def test_deterministic_limit_zero(self):
        """
        KERNEL:
        - rozkład deterministyczny → Θ = 0.
        """
        p = np.zeros(50)
        p[0] = 1.0
        theta = compute_theta_from_probs(p)
        assert theta < 0.05, f"Deterministic: Θ={theta:.3f} powinno być bliskie 0"

    def test_uniform_limit_one(self):
        """
        KERNEL:
        - rozkład jednostajny → Θ ≈ 1.
        """
        p = np.ones(100) / 100.0
        theta = compute_theta_from_probs(p)
        assert theta > 0.95, f"Uniform: Θ={theta:.3f} powinno być bliskie 1"

    def test_monotonic_with_softmax_temperature(self):
        """
        KERNEL:
        - zwiększanie temperatury softmaxu → wzrost Θ.
        """
        rng = np.random.default_rng(4)
        logits = rng.normal(size=(64, 40))

        def softmax(x, T):
            x = (x - x.max(axis=-1, keepdims=True)) / T
            ex = np.exp(x)
            return ex / ex.sum(axis=-1, keepdims=True)

        temperatures = [0.1, 0.5, 1.0, 2.0]
        theta_vals = []

        for T in temperatures:
            p = softmax(logits, T)
            theta = compute_theta_output_channel(p)
            theta_vals.append(theta)

        for i in range(len(theta_vals) - 1):
            assert theta_vals[i] <= theta_vals[i + 1] + 1e-2, \
                f"Θ nie jest monotoniczne z T: {theta_vals}"


# =============================================================================
# ENTROPY — FIDELITY
# =============================================================================

class TestEntropyFidelity:
    """S_spectral musi realizować intuicje entropii konfiguracyjnej widma."""

    def test_rank1_entropy_minimal(self):
        """
        KERNEL:
        - macierz rank–1 → minimalna entropia widmowa.
        """
        rng = np.random.default_rng(5)
        v = rng.normal(size=80)
        v /= np.linalg.norm(v) + 1e-12
        X = np.outer(np.ones(200), v)

        _, S_norm = compute_spectral_entropy(X)
        assert S_norm < 0.1, f"Rank-1: S_norm={S_norm:.3f} powinno być bliskie 0"

    def test_isotropic_entropy_maximal(self):
        """
        KERNEL:
        - macierz o spektrum ~jednostajnym → maksymalna entropia.
        """
        rng = np.random.default_rng(6)
        X = rng.normal(size=(400, 40))  # izotropowy szum

        _, S_norm = compute_spectral_entropy(X)
        assert S_norm > 0.9, f"Izotropia: S_norm={S_norm:.3f} powinno być bliskie 1"

    def test_effective_dimensionality_reasonable(self):
        """
        KERNEL:
        - d_eff ≈ liczba głównych kierunków w macierzy.
        """
        rng = np.random.default_rng(7)
        k = 10
        strong = rng.normal(size=(300, k))
        weak = rng.normal(size=(300, 50)) * 0.01
        X = np.concatenate([strong, weak], axis=1)

        d_eff = compute_effective_dimensionality(X)
        assert k * 0.5 < d_eff < k * 2.0, \
            f"d_eff={d_eff:.2f} nie odpowiada spodziewanej liczbie kierunków (~{k})"


# =============================================================================
# FREE ENERGY — FIDELITY
# =============================================================================

class TestFreeEnergyFidelity:
    """F = E − ΘS musi mieć poprawną strukturę jakościową."""

    def test_monotonic_in_error(self):
        """
        KERNEL:
        - F rośnie z E przy stałych Θ, S.
        """
        Theta, S = 0.4, 0.6
        E_vals = [0.0, 0.2, 0.5, 0.9]
        F_vals = [compute_free_energy(E, Theta, S) for E in E_vals]

        for i in range(len(F_vals) - 1):
            assert F_vals[i] <= F_vals[i + 1] + 1e-12, \
                f"F nie rośnie z E: {F_vals}"

    def test_minimum_near_adaptive_regime(self):
        """
        KERNEL:
        - F minimalne przy:
            E niskie,
            Θ umiarkowana,
            S wysokie (ale nie maksymalne).
        """
        F_good = compute_free_energy(E_norm=0.1, theta=0.4, S_norm=0.8)
        F_bad_error = compute_free_energy(E_norm=0.9, theta=0.4, S_norm=0.8)
        F_bad_random = compute_free_energy(E_norm=0.1, theta=0.9, S_norm=0.9)
        F_bad_rigid = compute_free_energy(E_norm=0.1, theta=0.1, S_norm=0.2)

        F_min_bad = min(F_bad_error, F_bad_random, F_bad_rigid)

        assert F_good < F_min_bad, \
            f"F nie ma minimum w reżimie adaptacyjnym: F_good={F_good:.3f}, F_bad_min={F_min_bad:.3f}"


# =============================================================================
# SUMMARY
# =============================================================================

def test_fidelity_summary():
    """Podsumowanie Level 1 — przydaje się w logach CI."""
    print("\n" + "="*60)
    print("LEVEL 1: IMPLEMENTATION FIDELITY (σ, Θ, S, F)")
    print("="*60)
    print("✓ σ: limity porządku/nieporządku, monotoniczność, rotacje")
    print("✓ Θ: limity deterministyczny/jednostajny, monotoniczność z T")
    print("✓ S: zachowanie rank–1 vs izotropia, d_eff ≈ liczba kierunków")
    print("✓ F: monotoniczność w E, minimum w reżimie adaptacyjnym")
    print("="*60 + "\n")
