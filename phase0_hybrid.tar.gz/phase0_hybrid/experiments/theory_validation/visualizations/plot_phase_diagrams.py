"""
Visualization Tools for Theory Validation

Generate publication-quality plots of F landscape, phase diagrams, RG flow.
"""

import numpy as np
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D

try:
    from adaptonic_metrics.core.free_energy import compute_free_energy
    from adaptonic_metrics.core.sigma import compute_sigma_spectral
    from adaptonic_metrics.core.entropy import compute_spectral_entropy
except ImportError:
    print("WARNING: adaptonic_metrics not found.")
    
    def compute_free_energy(E, theta, S):
        return E - theta * S
    
    def compute_sigma_spectral(X):
        U, s, Vt = np.linalg.svd(X, full_matrices=False)
        s_normalized = s / (s.sum() + 1e-12)
        return s_normalized[0] if len(s_normalized) > 0 else 0.0
    
    def compute_spectral_entropy(X):
        U, s, Vt = np.linalg.svd(X, full_matrices=False)
        s_normalized = s / (s.sum() + 1e-12)
        S_raw = -np.sum(s_normalized * np.log(s_normalized + 1e-12))
        S_max = np.log(len(s_normalized))
        S_norm = S_raw / S_max if S_max > 0 else 0.0
        return S_raw, S_norm


def plot_F_landscape_2D(save_path='F_landscape_2D.png'):
    """Plot F(E, Θ) heatmap at fixed S."""
    fig, axes = plt.subplots(1, 3, figsize=(15, 4))
    
    S_values = [0.3, 0.5, 0.7]
    
    for ax, S_fixed in zip(axes, S_values):
        E_range = np.linspace(0.0, 1.0, 100)
        theta_range = np.linspace(0.0, 1.0, 100)
        E_grid, Theta_grid = np.meshgrid(E_range, theta_range)
        
        F_grid = np.zeros_like(E_grid)
        for i in range(len(E_range)):
            for j in range(len(theta_range)):
                F_grid[j, i] = compute_free_energy(E_grid[j, i], Theta_grid[j, i], S_fixed)
        
        im = ax.contourf(E_grid, Theta_grid, F_grid, levels=20, cmap='RdYlBu_r')
        ax.contour(E_grid, Theta_grid, F_grid, levels=10, colors='k', alpha=0.3, linewidths=0.5)
        
        min_idx = np.unravel_index(np.argmin(F_grid), F_grid.shape)
        E_min = E_grid[min_idx]
        Theta_min = Theta_grid[min_idx]
        ax.plot(E_min, Theta_min, 'r*', markersize=15, label='Global minimum')
        
        ax.set_xlabel('E (task error)', fontsize=12)
        ax.set_ylabel('Θ (information temperature)', fontsize=12)
        ax.set_title(f'F landscape (S={S_fixed:.1f})', fontsize=13)
        ax.legend()
        
        plt.colorbar(im, ax=ax, label='F')
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"Saved: {save_path}")
    plt.close()


def plot_phase_diagram(save_path='phase_diagram.png'):
    """Plot phase diagram."""
    fig, ax = plt.subplots(figsize=(8, 6))
    
    n = 100
    E_range = np.linspace(0.0, 1.0, n)
    theta_range = np.linspace(0.0, 1.0, n)
    E_grid, Theta_grid = np.meshgrid(E_range, theta_range)
    
    S_fixed = 0.7
    F_threshold = 0.5
    
    F_grid = np.zeros_like(E_grid)
    for i in range(n):
        for j in range(n):
            F_grid[j, i] = compute_free_energy(E_grid[j, i], Theta_grid[j, i], S_fixed)
    
    intentional_mask = (F_grid < F_threshold).astype(int)
    
    ax.contourf(E_grid, Theta_grid, intentional_mask, 
                levels=[0, 0.5, 1], colors=['lightcoral', 'lightgreen'],
                alpha=0.6)
    ax.contour(E_grid, Theta_grid, F_grid, levels=[F_threshold], 
               colors='k', linewidths=2, linestyles='--')
    
    ax.text(0.7, 0.5, 'Non-Intentional\n(High F)', fontsize=12, ha='center')
    ax.text(0.15, 0.5, 'Intentional\n(Low F)', fontsize=12, ha='center')
    
    ax.set_xlabel('E (task error)', fontsize=12)
    ax.set_ylabel('Θ (exploration)', fontsize=12)
    ax.set_title(f'Phase Diagram (S={S_fixed}, F_crit={F_threshold})', fontsize=14)
    ax.grid(alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"Saved: {save_path}")
    plt.close()


if __name__ == '__main__':
    """Generate plots."""
    print("Generating theory validation visualizations...")
    plot_F_landscape_2D()
    plot_phase_diagram()
    print("\n✓ Visualizations generated")
