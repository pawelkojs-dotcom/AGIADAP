# Mathematical Foundations - Theorems P2 & P4

**Purpose:** Formal mathematical foundations for Phase 0 theory validation.

This document provides rigorous proofs and derivations for:
- **P2:** Stabilization of σ field via gradient flow
- **P4:** Intentional regime as global minimum of F

**Based on:** Continuous dynamical systems, Lyapunov theory, convex analysis.

---

## 1. Basic Dynamical Model

### 1.1. System Setup

We work in continuous time with finite-dimensional state space:

**State space:** σ(t) ∈ ℝ^d (representation/coherence field)

**Free energy functional** (for fixed Θ):
```
F(σ; Θ) = E(σ) − Θ·S(σ)
```

**Dynamics** (deterministic gradient flow):
```
γ·σ̇(t) = −∇_σ F(σ(t); Θ)     ... (1)
```

where:
- E(σ) — task cost / coherence energy
- S(σ) — configurational entropy (representational richness)
- Θ ≥ 0 — information temperature (fixed parameter)
- γ > 0 — effective viscosity (time scale)

**Note:** We treat Θ as external parameter (not coupled dynamics). This suffices for P2/P4.

---

## 2. Theorem P2: Stabilization of σ Field

### 2.1. Intuition

**Informal statement:**
> "If the system learns in a 'good' Θ range, then the coherence field σ(t) stabilizes:
> |σ̇(t)| → 0, σ(t) → σ*, and F(σ(t)) monotonically decreases."

This formalizes as a **gradient flow convergence theorem**.

### 2.2. Assumptions

**(A1) E is strongly convex:**
```
E ∈ C²(ℝ^d),  ∃ m_E > 0: ∀σ, ∇²E(σ) ⪰ m_E I
```

**(A2) S is smooth and weakly concave:**
```
S ∈ C²(ℝ^d),  ∃ L_S ≥ 0: ||∇²S(σ)|| ≤ L_S
```

**(A3) Θ is in "good" band:**
```
0 ≤ Θ ≤ Θ_max,  where m_F := m_E − Θ_max·L_S > 0
```

This ensures F remains **strongly convex**:
```
∇²F(σ; Θ) = ∇²E(σ) − Θ·∇²S(σ) ⪰ m_E·I − Θ_max·L_S·I = m_F·I ≻ 0
```

### 2.3. Theorem P2 (Continuous σ(t))

> **Theorem P2 (Stabilization via gradient flow):**
> 
> Under assumptions (A1–A3), for fixed 0 ≤ Θ ≤ Θ_max, the equation
> ```
> γ·σ̇(t) = −∇F(σ(t); Θ)
> ```
> has exactly one equilibrium point σ*(Θ), which is:
> 
> 1. Global minimizer of F
> 2. Globally asymptotically stable
> 3. Satisfies:
>    ```
>    lim_{t→∞} σ(t) = σ*(Θ)
>    lim_{t→∞} σ̇(t) = 0
>    ```
> 4. F(σ(t); Θ) is a Lyapunov function (monotonically decreasing)

### 2.4. Proof (Sketch)

**Step 1: Existence and uniqueness of σ***

Strong convexity of F (m_F > 0) implies existence of exactly one minimizer σ* (classical result from convex analysis).

**Step 2: Lyapunov function**

Let F(t) = F(σ(t); Θ). Then:
```
dF/dt = ∇F(σ)·σ̇
      = ∇F(σ)·(−1/γ·∇F(σ))
      = −1/γ·||∇F(σ)||² ≤ 0
```

Therefore F is a Lyapunov function, strictly decreasing except at equilibrium.

**Step 3: Convergence to σ***

Strong convexity + gradient flow + Lyapunov function ⇒ global asymptotic stability of σ*.

This is a standard result from dynamical systems theory for strongly convex potentials.

**Step 4: Stabilization**

Convergence σ(t) → σ* and smoothness imply σ̇(t) → 0.

### 2.5. Interpretation

In the regime where F is strongly convex (Θ not too large to "kill" convexity of E):

- System always finds unique, stable σ*
- F(t) monotonically decreases
- σ(t) stops changing: **this is the formal content of P2**

### 2.6. Discrete Version (for H_GEN_1 / Campaign #4)

In practice, we have iterations:
```
σ_{k+1} = σ_k − η·∇F(σ_k; Θ)
```

For small step η > 0, if F is strongly convex and η < 2/m_F, we get classical gradient descent convergence to σ*.

**Operational P2 for Campaign #4:**

Define σ_session_n (e.g., average coherence in session n).

> **P2 (discrete version):**
> There exists σ* and N such that for n ≥ N:
> ```
> |σ_{n+1} − σ_n| < ε
> |σ_n − σ*| < ε
> ```
> with fixed small ε.

This can be tested by fitting a curve to σ_n vs n and checking convergence.

---

## 3. Theorem P4: Intentional Regime as F Minimum

### 3.1. Problem with "Bare" F = E − Θ·S

For **fixed** E(σ), S(σ) and varying only Θ:
```
F(σ; Θ) = E(σ) − Θ·S(σ)
```

This is **linear in Θ**. For S > 0, F decreases with Θ. No "inverted-U" or "optimal Θ".

**Solution:** E must also depend on Θ. In adaptive theory, we assume high Θ increases stabilization cost:

### 3.2. Extended Functional

```
F(σ; Θ) = E_0(σ) + α·Θ² − Θ·S(σ)     ... (2)
```

where:
- E_0(σ) — "pure" task cost for configuration σ
- α·Θ² — cost of over-exploration / chaos (high temperature)
- −Θ·S(σ) — standard entropic term

### 3.3. Theorem P4a (Local Optimum in Θ)

For fixed σ with S(σ) = S > 0:
```
F(Θ) = E_0(σ) + α·Θ² − Θ·S
```

**Minimum w.r.t. Θ:**
```
dF/dΘ = 2α·Θ − S = 0  ⇒  Θ*(σ) = S(σ)/(2α)
```

**Second derivative:**
```
d²F/dΘ² = 2α > 0
```

Therefore Θ*(σ) is a **minimum**.

> **Theorem P4a (local):**
> If F has form (2), then for any σ with S(σ) > 0, there exists exactly one optimum:
> ```
> Θ*(σ) = S(σ)/(2α)
> ```
> where F(σ; Θ) is minimal w.r.t. Θ.

**This is the formal "inverted-U" for Θ.**

By scaling α, we can set typical Θ* ≈ 0.1–0.2.

### 3.4. Theorem P4 (Global Minimum in Intentional Regime)

We now want a stronger statement:

> There exists a pair (σ*, Θ*) such that:
> - E_0(σ*) is small (good task solution)
> - S(σ*) is moderately large (rich, non-chaotic representation)
> - Θ* is moderate (not zero, not maximum)
> - F(σ*, Θ*) < F for all other "non-intentional" configurations

This requires:

1. Assumptions about E_0(σ): has global minimum in regime of sensible task solutions
2. Assumptions about S(σ): max S corresponds to chaotic, useless representations
3. Connection: "intentionality" = region where:
   - E_0(σ) ≤ E_good
   - S(σ) ≥ S_min_rich
   - Θ*(σ) ∈ [Θ_low, Θ_high]

**Formal Sketch:**

> **Theorem P4 (global minimum, working draft):**
> 
> Assume:
> - E_0(σ) has global minimum in set 𝓘 ⊂ ℝ^d corresponding to "good task representations" (E_0(σ) ≤ E_good)
> - S(σ) ≥ S_min on 𝓘 (representations not trivial/degenerate)
> - F has form (2) with α > 0
> 
> Then there exists (σ*, Θ*) with σ* ∈ 𝓘, Θ* = S(σ*)/(2α), such that:
> ```
> F(σ*, Θ*) = min_{σ,Θ} F(σ, Θ)
> ```
> 
> In other words, the global minimum of F lies in the regime of low E_0, moderate Θ, and rich (but not maximal) entropy S — which we interpret as the **intentional regime**.

This is not a "big mathematical theorem" but an **operational, sufficient definition of P4** that:

- Encodes "inverted-U" for Θ
- Ensures optimum is where task is well-solved (E_0 low)
- And representations are non-trivial (S_min)

---

## 4. Stability Analysis Around F Minimum

### 4.1. Hessian and Linear Stability

Around σ*, we have:
```
γ·σ̇ = −∇F(σ; Θ)
```

**Linearization:**

Let δσ = σ − σ*. Then:
```
γ·δσ̇ ≈ −H_F(σ*)·δσ
```

where H_F = ∇²F is the Hessian.

**General solution:**
```
δσ(t) = Σ_i c_i·exp(−λ_i·t/γ)·v_i
```

where λ_i are eigenvalues of H_F, v_i are eigenvectors.

### 4.2. Stability Condition

**Linear stability:**
```
λ_i > 0  ∀i  ⇒  σ* is linearly stable
```

This is **exactly equivalent to:**
- E actively convex
- S doesn't "kill" convexity of E
- Θ in reasonable range

**In your theory:**

> "Intentional point (σ*, Θ*) is a stable minimum of F if the Hessian of F is positive definite at σ*."

This can be:
- Written formally in KERNEL
- Used in H_GEN_1 as criterion (evaluate Hessian/approx in training context)

---

## 5. Integration with KERNEL_AGI

### 5.1. For KERNEL_AGI.md

Add sections:

```markdown
## P2 — Stabilization of σ Field via Gradient Flow

**Assumptions:**
- E(σ) strongly convex (∃ m_E>0: ∇²E(σ) ⪰ m_E·I)
- S(σ) smooth, weakly concave (||∇²S(σ)|| ≤ L_S)
- Θ ∈ [0, Θ_max], where m_F := m_E − Θ_max·L_S > 0

**Theorem (P2):**
For fixed Θ, the equation:
```
γ·σ̇(t) = −∇F(σ(t); Θ)
```
with F(σ;Θ) = E(σ) − Θ·S(σ), has exactly one equilibrium σ* (global minimizer of F), which is globally asymptotically stable:
```
lim_{t→∞} σ(t) = σ*
lim_{t→∞} σ̇(t) = 0
```
and F(σ(t);Θ) is a Lyapunov function (monotonically decreasing).

**Interpretation:**
P2 formalizes the observation that with "good" Θ, the coherence field σ stabilizes to equilibrium.
```

And:

```markdown
## P4 — Minimum of F in Intentional Regime

Extended functional:
```
F(σ; Θ) = E_0(σ) + α·Θ² − Θ·S(σ),  α>0
```

**Theorem (P4 – local):**
For any configuration σ with S(σ)>0, there exists exactly one optimum:
```
Θ*(σ) = S(σ) / (2α)
```
where F(σ;Θ) is minimal w.r.t. Θ.

**Theorem (P4 – global, sketch):**
If:
- E_0(σ) has global minimum on set 𝓘 (representations solving task well)
- S(σ) ≥ S_min on 𝓘 (representations rich, not degenerate)

Then there exists (σ*, Θ*) with σ*∈𝓘, Θ*=S(σ*)/(2α) such that:
```
F(σ*,Θ*) = min_{σ,Θ} F(σ,Θ)
```

**Interpretation:**
P4 formalizes that the global minimum of F (intentional regime) is achieved at:
- Low task error
- Moderate Θ
- Non-zero entropy S
```

---

## 6. Connection to Tests

### Level 1: test_fidelity.py
Validates basic properties:
- σ limits (order/disorder)
- Θ limits (deterministic/uniform)
- S limits (rank-1/isotropic)
- F monotonicity in E

### Level 2: test_scaling.py
Validates RG properties:
- Finite-size scaling (σ(N) → σ_∞)
- Coarse-graining stability
- Critical scaling near transitions

### Level 3: test_topology.py
Validates global structure:
- Morse theory (critical points)
- Basin connectivity
- Gradient flow convergence

**Mathematical foundations ensure implementation correctness.**

---

## 7. References

**Theory:**
- Wilson (1971): Renormalization Group methods
- Landau (1937): Phase transition theory
- Lyapunov (1892): Stability theory
- Rockafellar (1970): Convex analysis

**Adaptonic Theory:**
- KERNEL_AGI.md — field definitions
- INVARIANTS_AGI.md — domain constraints
- ADR-2025-11-20 — Spectral metrics adoption

---

**Version:** 1.0  
**Status:** Formal mathematical foundations for Phase 0  
**Date:** 2025-11-21
