#!/bin/bash
# Verify Phase 0 Hybrid Package

echo "🔍 Verifying Phase 0 Hybrid Package..."
echo ""

ERRORS=0

echo "📚 Documentation:"
for file in "MANIFEST.md" "experiments/theory_validation/00_README_PHASE0.md"; do
    if [ -f "$file" ]; then
        echo "  ✅ $file"
    else
        echo "  ❌ $file - MISSING"
        ERRORS=$((ERRORS+1))
    fi
done

echo ""
echo "🧪 Test Files:"
for file in "test_axioms.py" "test_fidelity.py" "test_scaling.py" "test_topology.py"; do
    if [ -f "experiments/theory_validation/$file" ]; then
        lines=$(wc -l < "experiments/theory_validation/$file")
        echo "  ✅ $file ($lines lines)"
    else
        echo "  ❌ $file - MISSING"
        ERRORS=$((ERRORS+1))
    fi
done

echo ""
echo "📐 Theory:"
if [ -f "experiments/theory_validation/theory/MATHEMATICAL_FOUNDATIONS.md" ]; then
    lines=$(wc -l < "experiments/theory_validation/theory/MATHEMATICAL_FOUNDATIONS.md")
    echo "  ✅ MATHEMATICAL_FOUNDATIONS.md ($lines lines)"
else
    echo "  ❌ MATHEMATICAL_FOUNDATIONS.md - MISSING"
    ERRORS=$((ERRORS+1))
fi

echo ""
echo "🔧 Infrastructure:"
for file in "__init__.py" "run_full_validation.sh" "visualizations/plot_phase_diagrams.py"; do
    if [ -f "experiments/theory_validation/$file" ]; then
        echo "  ✅ $file"
    else
        echo "  ❌ $file - MISSING"
        ERRORS=$((ERRORS+1))
    fi
done

echo ""
if [ $ERRORS -eq 0 ]; then
    echo "✅ Package verification: PASSED"
    echo ""
    echo "Hybrid approach complete:"
    echo "  - GPT simple tests (L0-1)"
    echo "  - Claude physics tests (L2-3)"
    echo "  - GPT mathematical formalism (theory/)"
    echo ""
    echo "Ready to download!"
else
    echo "❌ Package verification: FAILED"
    echo ""
    echo "Found $ERRORS missing files"
    exit 1
fi
