
from __future__ import annotations
import random
from typing import Optional

from .data_structures import ArchitectureConfig, Metrics


class FakeEvaluator:
    """Minimal synthetic evaluator for PoC v0.1.

    It does *not* run any real INTAGI / AFLM code. Instead it produces
    plausible-looking metrics with simple heuristics:
    - more layers → higher n_eff
    - theta close to 0.12 → better F_delta
    - moderate gamma → better coherence
    """

    def __init__(self, seed: Optional[int] = None) -> None:
        self._rng = random.Random(seed)

    def evaluate(self, config: ArchitectureConfig) -> Metrics:
        # n_eff grows with layers but with diminishing returns
        base_n_eff = 2.5 + 0.4 * config.n_layers
        n_eff = base_n_eff + self._rng.gauss(0.0, 0.25)

        # F_delta: aim for ~ -0.1 when theta near 0.12
        theta_opt = 0.12
        theta_diff = abs(config.theta - theta_opt)
        F_delta_mean = -0.05 - 0.5 * max(0.0, 0.12 - theta_diff)
        F_delta = F_delta_mean + self._rng.gauss(0.0, 0.02)

        # I_ratio: modest correlation with n_eff
        I_ratio = 0.20 + 0.03 * max(0.0, n_eff - 3.0)
        I_ratio += self._rng.uniform(-0.03, 0.05)

        # sigma_coh: highest for gamma ~0.5
        gamma_opt = 0.5
        gamma_diff = abs(config.gamma - gamma_opt)
        sigma_coh = 0.75 + 0.15 * max(0.0, 0.3 - gamma_diff)
        sigma_coh += self._rng.uniform(-0.05, 0.05)
        sigma_coh = max(0.0, min(1.0, sigma_coh))

        # Task score: loosely tied to n_eff and sigma_coh
        task_score = 0.6 + 0.05 * (n_eff - 3.5) + 0.1 * (sigma_coh - 0.7)
        task_score += self._rng.uniform(-0.1, 0.1)
        task_score = max(0.0, min(1.0, task_score))

        return Metrics(
            config_id=config.id,
            F_delta=F_delta,
            n_eff=n_eff,
            I_ratio=I_ratio,
            sigma_coh=sigma_coh,
            task_score=task_score,
            safety_score=1.0,
        )


class RealEvaluator:
    """Placeholder for future INTAGI-based evaluator.

    Left unimplemented in PoC v0.1.
    """

    def __init__(self, *_, **__) -> None:
        raise NotImplementedError("RealEvaluator is not implemented in PoC v0.1")
