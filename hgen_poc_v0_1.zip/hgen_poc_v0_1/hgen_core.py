
from __future__ import annotations
from typing import Optional, List
from datetime import datetime
import json

from .data_structures import ArchitectureSpec, ArchitectureConfig, Metrics, HGENOutput
from .mutator import ArchitectureMutator
from .evaluator import FakeEvaluator
from .selector import ArchitectureSelector


class HGENCore:
    """Minimal HGEN core for PoC v0.1.

    This implements the Phase 1 workflow from HGEN_IMPLEMENTATION_PLAN:
    - generate N variants with ArchitectureMutator
    - evaluate them with FakeEvaluator
    - select best with ArchitectureSelector
    - log a short session record
    """

    def __init__(self, seed: Optional[int] = None, log_path: str = "hgen_sessions.log") -> None:
        self.mutator = ArchitectureMutator(seed=seed)
        self.evaluator = FakeEvaluator(seed=seed)
        self.selector = ArchitectureSelector()
        self.log_path = log_path
        self.sessions: List[dict] = []

    def generate_optimal_architecture(
        self,
        spec: ArchitectureSpec,
        baseline: Optional[ArchitectureConfig] = None,
        n_variants: int = 5,
        objective: str = "R4_capable",
    ) -> HGENOutput:
        # Safety-ish check: validate spec, but do *not* do heavy safety here.
        spec.validate()

        # 1. Generate configs
        configs = self.mutator.mutate(spec, baseline=baseline, n_variants=n_variants)

        # 2. Evaluate
        metrics: List[Metrics] = []
        for cfg in configs:
            m = self.evaluator.evaluate(cfg)
            metrics.append(m)

        # 3. Select best
        best_idx = self.selector.select(configs, metrics, objective=objective)
        best_cfg = configs[best_idx]
        best_metrics = metrics[best_idx]

        # 4. Build output
        alternatives = [cfg for i, cfg in enumerate(configs) if i != best_idx]
        output = HGENOutput(
            status="PROPOSED",
            timestamp=datetime.now(),
            best_config=best_cfg,
            best_metrics=best_metrics,
            alternatives=alternatives,
            requires_approval=True,
            approved_by=None,
        )

        # 5. Log session (very lightweight JSON line)
        self._log_session(spec, configs, metrics, best_idx)

        return output

    # ------------------------------------------------------------------

    def _log_session(
        self,
        spec: ArchitectureSpec,
        configs: List[ArchitectureConfig],
        metrics: List[Metrics],
        best_idx: int,
    ) -> None:
        record = {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "spec": {
                "model_type": spec.model_type,
                "layers_range": spec.layers_range,
                "hidden_dim_options": spec.hidden_dim_options,
                "theta_range": spec.theta_range,
                "gamma_range": spec.gamma_range,
                "lambda_range": spec.lambda_range,
                "adaptation_steps_range": spec.adaptation_steps_range,
            },
            "n_variants": len(configs),
            "best_index": int(best_idx),
            "best_id": configs[best_idx].id,
            "best_metrics": metrics[best_idx].as_dict(),
        }
        self.sessions.append(record)
        try:
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
        except Exception:
            # PoC: logging failures are non-fatal
            pass
