
from __future__ import annotations

from hgen_poc_v0_1.data_structures import ArchitectureSpec
from hgen_poc_v0_1.hgen_core import HGENCore


def main() -> None:
    # Define a small search space around an INTAGI_A0-like baseline
    spec = ArchitectureSpec(
        model_type="INTAGI_A0",
        layers_range=[3, 4, 5],
        hidden_dim_options=[256, 512],
        theta_range=[0.10, 0.12, 0.14],
        gamma_range=[0.4, 0.5, 0.6],
        lambda_range=[2.5, 3.0, 3.5],
        adaptation_steps_range=[2, 3, 4],
    )

    hgen = HGENCore(seed=42)
    output = hgen.generate_optimal_architecture(spec, n_variants=5)

    print("=" * 60)
    print("HGEN PoC v0.1 – demo run")
    print("=" * 60)
    print(output.short_summary())
    print("\nBest configuration:")
    cfg = output.best_config
    if cfg is not None:
        print(f"  id          : {cfg.id}")
        print(f"  model_type  : {cfg.model_type}")
        print(f"  n_layers    : {cfg.n_layers}")
        print(f"  hidden_dim  : {cfg.hidden_dim}")
        print(f"  theta       : {cfg.theta}")
        print(f"  gamma       : {cfg.gamma}")
        print(f"  lambda_0    : {cfg.lambda_0}")
        print(f"  adapt_steps : {cfg.adaptation_steps}")
    print("=" * 60)
    print("NOTE: metrics are synthetic (FakeEvaluator).")
    print("      This is Phase 1 skeleton PoC, no INTAGI yet.")


if __name__ == "__main__":
    main()
