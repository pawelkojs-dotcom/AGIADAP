
from __future__ import annotations
from typing import List, Literal

from .data_structures import ArchitectureConfig, Metrics


class ArchitectureSelector:
    """Pick the best architecture according to a simple scalar score.

    This is intentionally simple for PoC v0.1:
    score = -F_delta  +  0.5 * n_eff  +  0.3 * sigma_coh
    """

    def select(
        self,
        configs: List[ArchitectureConfig],
        metrics: List[Metrics],
        objective: Literal['R4_capable', 'efficient', 'safe'] = 'R4_capable',
    ) -> int:
        if len(configs) != len(metrics):
            raise ValueError("configs and metrics must have the same length")
        if not configs:
            raise ValueError("configs list is empty")

        scores = []
        for m in metrics:
            if objective == 'R4_capable':
                score = self._score_r4(m)
            elif objective == 'efficient':
                score = self._score_efficient(m)
            elif objective == 'safe':
                score = self._score_safe(m)
            else:
                raise ValueError(f"Unknown objective: {objective}")
            scores.append(score)

        # Return index of max score
        best_idx = max(range(len(scores)), key=lambda i: scores[i])
        return int(best_idx)

    # --- scoring helpers ----------------------------------------------

    def _score_r4(self, m: Metrics) -> float:
        # F_delta smaller is better → negate
        score = -m.F_delta * 10.0
        score += (m.n_eff - 4.0) * 5.0
        score += (m.I_ratio - 0.3) * 3.0
        if m.sigma_coh < 0.7:
            score -= 5.0
        return score

    def _score_efficient(self, m: Metrics) -> float:
        # In PoC we do not know params, so just reuse task_score
        return m.task_score

    def _score_safe(self, m: Metrics) -> float:
        return m.safety_score
