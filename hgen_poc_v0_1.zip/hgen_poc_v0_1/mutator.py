
from __future__ import annotations
import random
import string
from typing import List, Optional

from .data_structures import ArchitectureSpec, ArchitectureConfig


class ArchitectureMutator:
    """Generate architecture variants by mutating a baseline or sampling from spec.

    This is a *minimal* implementation corresponding to Phase 1 in the
    IMPLEMENTATION_PLAN: simple random sampling + light mutations.
    """

    def __init__(self, seed: Optional[int] = None) -> None:
        self._rng = random.Random(seed)

    def _random_id(self, length: int = 8) -> str:
        alphabet = string.ascii_lowercase + string.digits
        return ''.join(self._rng.choice(alphabet) for _ in range(length))

    def mutate(
        self,
        spec: ArchitectureSpec,
        baseline: Optional[ArchitectureConfig] = None,
        n_variants: int = 5,
    ) -> List[ArchitectureConfig]:
        """Generate n_variants configurations within the given spec.

        If baseline is provided, we perform light mutations around it.
        Otherwise we sample independently from the spec ranges.
        """
        if n_variants <= 0:
            raise ValueError("n_variants must be positive")

        spec.validate()

        variants: List[ArchitectureConfig] = []
        for _ in range(n_variants):
            if baseline is None:
                config = self._random_sample(spec)
            else:
                config = self._mutate_from_baseline(baseline, spec)
            variants.append(config)
        return variants

    # --- helpers -----------------------------------------------------

    def _random_sample(self, spec: ArchitectureSpec) -> ArchitectureConfig:
        return ArchitectureConfig(
            id=self._random_id(),
            model_type=spec.model_type,
            n_layers=self._rng.choice(spec.layers_range),
            hidden_dim=self._rng.choice(spec.hidden_dim_options),
            theta=self._rng.choice(spec.theta_range),
            gamma=self._rng.choice(spec.gamma_range),
            lambda_0=self._rng.choice(spec.lambda_range),
            adaptation_steps=self._rng.choice(spec.adaptation_steps_range),
        )

    def _mutate_from_baseline(
        self,
        baseline: ArchitectureConfig,
        spec: ArchitectureSpec,
    ) -> ArchitectureConfig:
        # Start from a shallow copy of the baseline
        cfg_dict = baseline.as_dict()
        cfg_dict["id"] = self._random_id()

        # Decide which parameters to mutate (1–2 of them)
        params = ["n_layers", "hidden_dim", "theta", "gamma", "adaptation_steps"]
        n_mut = self._rng.choice([1, 2])
        to_mutate = self._rng.sample(params, k=n_mut)

        for p in to_mutate:
            if p == "n_layers":
                cfg_dict[p] = self._rng.choice(spec.layers_range)
            elif p == "hidden_dim":
                cfg_dict[p] = self._rng.choice(spec.hidden_dim_options)
            elif p == "theta":
                cfg_dict[p] = self._rng.choice(spec.theta_range)
            elif p == "gamma":
                cfg_dict[p] = self._rng.choice(spec.gamma_range)
            elif p == "adaptation_steps":
                cfg_dict[p] = self._rng.choice(spec.adaptation_steps_range)

        return ArchitectureConfig(**cfg_dict)
