
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Literal, Optional
from datetime import datetime


@dataclass
class ArchitectureSpec:
    """Specification of the search space for architectures.

    This corresponds to the PHASE 0/1 spec in HGEN_IMPLEMENTATION_PLAN.
    """
    model_type: Literal['AFLM', 'INTAGI_A0', 'INTAGI_A1']
    layers_range: List[int]
    hidden_dim_options: List[int]
    theta_range: List[float]
    gamma_range: List[float]
    lambda_range: List[float]
    adaptation_steps_range: List[int]

    def validate(self) -> None:
        """Basic safety / sanity validation for the spec.

        This is intentionally minimal for PoC v0.1.
        """
        if 'HGEN' in self.model_type.upper():
            # Hard stop against recursion / self-targeting.
            raise RecursionError("ArchitectureSpec.model_type cannot target HGEN")

        if not self.layers_range:
            raise ValueError("layers_range must not be empty")
        if not self.hidden_dim_options:
            raise ValueError("hidden_dim_options must not be empty")
        if not self.theta_range:
            raise ValueError("theta_range must not be empty")
        if not self.gamma_range:
            raise ValueError("gamma_range must not be empty")
        if not self.lambda_range:
            raise ValueError("lambda_range must not be empty")
        if not self.adaptation_steps_range:
            raise ValueError("adaptation_steps_range must not be empty")

        if any(l <= 0 for l in self.layers_range):
            raise ValueError("layers_range must contain positive integers only")

        # Very soft bounds on theta/gamma – just to catch gross errors.
        if any(t <= 0 or t > 1.0 for t in self.theta_range):
            raise ValueError("theta_range values must be in (0, 1.0]")
        if any(g <= 0 or g > 1.0 for g in self.gamma_range):
            raise ValueError("gamma_range values must be in (0, 1.0]")


@dataclass
class ArchitectureConfig:
    """Concrete configuration of an architecture variant.

    In the PoC this is still model-agnostic; it does *not* build any real
    model, it just carries parameters that the evaluator turns into
    synthetic metrics.
    """

    id: str
    model_type: str
    n_layers: int
    hidden_dim: int
    theta: float
    gamma: float
    lambda_0: float
    adaptation_steps: int

    def __post_init__(self) -> None:
        if 'HGEN' in str(self.model_type).upper():
            raise RecursionError("ArchitectureConfig.model_type cannot be HGEN")
        if self.n_layers <= 0:
            raise ValueError("n_layers must be positive")
        if self.hidden_dim <= 0:
            raise ValueError("hidden_dim must be positive")

    def as_dict(self) -> dict:
        return {
            "id": self.id,
            "model_type": self.model_type,
            "n_layers": self.n_layers,
            "hidden_dim": self.hidden_dim,
            "theta": self.theta,
            "gamma": self.gamma,
            "lambda_0": self.lambda_0,
            "adaptation_steps": self.adaptation_steps,
        }


@dataclass
class Metrics:
    """Evaluation results for one architecture variant (synthetic in PoC)."""

    config_id: str
    F_delta: float      # change in free energy proxy (lower is better)
    n_eff: float        # effective depth proxy
    I_ratio: float      # information / intentionality proxy
    sigma_coh: float    # coherence proxy
    task_score: float   # generic task score (0–1)
    safety_score: float = 1.0

    def as_dict(self) -> dict:
        return {
            "config_id": self.config_id,
            "F_delta": self.F_delta,
            "n_eff": self.n_eff,
            "I_ratio": self.I_ratio,
            "sigma_coh": self.sigma_coh,
            "task_score": self.task_score,
            "safety_score": self.safety_score,
        }


@dataclass
class HGENOutput:
    """Result of a single HGEN optimization session.

    This is still a *recommendation* object – it does not imply deployment.
    """

    status: Literal['PROPOSED', 'APPROVED', 'REJECTED'] = 'PROPOSED'
    timestamp: datetime = field(default_factory=datetime.now)
    best_config: Optional[ArchitectureConfig] = None
    best_metrics: Optional[Metrics] = None
    alternatives: List[ArchitectureConfig] = field(default_factory=list)
    requires_approval: bool = True
    approved_by: Optional[str] = None

    def short_summary(self) -> str:
        if self.best_config is None or self.best_metrics is None:
            return "HGENOutput(status=%s, empty)" % (self.status,)
        return (
            f"HGENOutput(status={self.status}, "
            f"best_id={self.best_config.id}, "
            f"layers={self.best_config.n_layers}, "
            f"theta={self.best_config.theta:.3f}, "
            f"gamma={self.best_config.gamma:.3f}, "
            f"F_delta={self.best_metrics.F_delta:.3f}, "
            f"n_eff={self.best_metrics.n_eff:.2f}, "
            f"sigma_coh={self.best_metrics.sigma_coh:.2f})"
        )
