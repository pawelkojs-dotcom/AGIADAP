# test_intagi_adapter placeholder
