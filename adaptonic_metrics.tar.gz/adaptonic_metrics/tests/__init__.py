"""Test suite for adaptonic_metrics."""
