"""
Basic tests for adaptonic_metrics core module.
"""

import numpy as np
import pytest
from adaptonic_metrics import (
    compute_sigma_spectral,
    compute_spectral_entropy,
    compute_theta_from_probs,
    compute_free_energy
)


class TestSigma:
    """Tests for coherence metrics."""
    
    def test_sigma_bounds(self):
        """σ should be in [0, 1]."""
        X = np.random.randn(50, 128)
        sigma = compute_sigma_spectral(X)
        assert 0.0 <= sigma <= 1.0
    
    def test_sigma_perfect_alignment(self):
        """Perfect alignment → σ ≈ 1."""
        # All agents identical
        X = np.ones((50, 128))
        sigma = compute_sigma_spectral(X)
        assert sigma > 0.99
    
    def test_sigma_random(self):
        """Random states → low σ."""
        X = np.random.randn(50, 128)
        sigma = compute_sigma_spectral(X)
        assert sigma < 0.5  # Typically much lower for random


class TestEntropy:
    """Tests for entropy metrics."""
    
    def test_entropy_bounds(self):
        """S_norm should be in [0, 1]."""
        X = np.random.randn(50, 128)
        S_raw, S_norm = compute_spectral_entropy(X)
        assert 0.0 <= S_norm <= 1.0
    
    def test_entropy_rank_one(self):
        """Rank-1 matrix → low entropy."""
        X = np.outer(np.ones(50), np.random.randn(128))
        S_raw, S_norm = compute_spectral_entropy(X)
        assert S_norm < 0.1
    
    def test_entropy_isotropic(self):
        """Isotropic → high entropy."""
        X = np.random.randn(50, 50) / np.sqrt(50)  # Square for max rank
        S_raw, S_norm = compute_spectral_entropy(X)
        assert S_norm > 0.8


class TestTheta:
    """Tests for temperature metrics."""
    
    def test_theta_bounds(self):
        """Θ should be in [0, 1]."""
        p = np.random.rand(100)
        p = p / p.sum()
        theta = compute_theta_from_probs(p)
        assert 0.0 <= theta <= 1.0
    
    def test_theta_deterministic(self):
        """Deterministic → Θ ≈ 0."""
        p = np.zeros(100)
        p[0] = 1.0
        theta = compute_theta_from_probs(p)
        assert theta < 0.01
    
    def test_theta_uniform(self):
        """Uniform → Θ ≈ 1."""
        p = np.ones(100) / 100
        theta = compute_theta_from_probs(p)
        assert theta > 0.99
    
    def test_theta_normalization(self):
        """p must sum to 1."""
        p = np.array([0.5, 0.3, 0.1])
        with pytest.raises(ValueError):
            compute_theta_from_probs(p)


class TestFreeEnergy:
    """Tests for free energy functional."""
    
    def test_free_energy_sign(self):
        """Low error + high entropy → negative F."""
        F = compute_free_energy(E_norm=0.1, theta=0.2, S_norm=0.8)
        assert F < 0
    
    def test_free_energy_high_error(self):
        """High error → positive F."""
        F = compute_free_energy(E_norm=0.9, theta=0.1, S_norm=0.2)
        assert F > 0
    
    def test_free_energy_zero_theta(self):
        """Θ=0 → F=E."""
        E = 0.5
        F = compute_free_energy(E_norm=E, theta=0.0, S_norm=0.5)
        assert abs(F - E) < 1e-10


class TestIntegration:
    """Integration tests."""
    
    def test_phase_transition(self):
        """R3 → R4 transition increases σ."""
        # Create trajectory with increasing alignment
        T, N, d = 50, 30, 64
        trajectory = np.random.randn(T, N, d)
        
        sigmas = []
        for t in range(T):
            alignment = t / T
            mean_state = np.mean(trajectory[t], axis=0)
            trajectory[t] = (1 - alignment) * trajectory[t] + alignment * mean_state
            
            sigma = compute_sigma_spectral(trajectory[t])
            sigmas.append(sigma)
        
        # σ should increase
        assert sigmas[-1] > sigmas[0]
        assert sigmas[-1] > 0.7  # Should reach R4
    
    def test_free_energy_minimization(self):
        """Free energy should decrease with optimization."""
        from adaptonic_metrics import find_optimal_theta, compute_free_energy_extended
        
        E = 0.2
        S = 0.6
        alpha = 0.1
        
        # Suboptimal theta
        F_bad = compute_free_energy_extended(E, theta=0.5, S_norm=S, alpha=alpha)
        
        # Optimal theta
        theta_opt = find_optimal_theta(S, alpha)
        F_opt = compute_free_energy_extended(E, theta_opt, S, alpha)
        
        assert F_opt < F_bad


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
