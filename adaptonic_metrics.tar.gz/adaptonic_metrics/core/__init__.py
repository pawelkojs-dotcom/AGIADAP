"""
Adaptonic Metrics - Core Module
================================

Core adaptonic field metrics: σ, Θ, S, F
"""

from .sigma import (
    compute_sigma_spectral,
    compute_participation_ratio,
    compute_coherence_from_covariance,
    compute_sigma_temporal,
    estimate_sigma_from_samples
)

from .entropy import (
    compute_spectral_entropy,
    compute_effective_dimensionality,
    compute_entropy_rate,
    compute_cross_entropy,
    compute_kl_divergence,
    compute_entropy_production,
    estimate_entropy_from_samples
)

from .theta import (
    compute_theta_from_probs,
    compute_theta_output_channel,
    compute_theta_circadian,
    compute_theta_adaptive,
    estimate_theta_from_actions,
    compute_theta_boltzmann,
    compute_effective_temperature,
    estimate_theta_from_samples
)

from .free_energy import (
    compute_free_energy,
    compute_free_energy_extended,
    find_optimal_theta,
    compute_free_energy_landscape,
    compute_gradient_free_energy,
    compute_stability_matrix,
    compute_phase_transition_point,
    compute_free_energy_difference,
    compute_free_energy_barrier,
    compute_dissipation_rate,
    estimate_free_energy_from_trajectory
)

__all__ = [
    # Sigma (Coherence)
    'compute_sigma_spectral',
    'compute_participation_ratio',
    'compute_coherence_from_covariance',
    'compute_sigma_temporal',
    'estimate_sigma_from_samples',
    
    # Entropy
    'compute_spectral_entropy',
    'compute_effective_dimensionality',
    'compute_entropy_rate',
    'compute_cross_entropy',
    'compute_kl_divergence',
    'compute_entropy_production',
    'estimate_entropy_from_samples',
    
    # Theta (Temperature)
    'compute_theta_from_probs',
    'compute_theta_output_channel',
    'compute_theta_circadian',
    'compute_theta_adaptive',
    'estimate_theta_from_actions',
    'compute_theta_boltzmann',
    'compute_effective_temperature',
    'estimate_theta_from_samples',
    
    # Free Energy
    'compute_free_energy',
    'compute_free_energy_extended',
    'find_optimal_theta',
    'compute_free_energy_landscape',
    'compute_gradient_free_energy',
    'compute_stability_matrix',
    'compute_phase_transition_point',
    'compute_free_energy_difference',
    'compute_free_energy_barrier',
    'compute_dissipation_rate',
    'estimate_free_energy_from_trajectory',
]
