"""
Spectral Entropy (S) Metrics
==============================

Measures representational diversity in multi-agent systems.
Based on: Kojs, P. (2025). AGI as Living Adapton.
"""

import numpy as np
from typing import Optional, Tuple


def compute_spectral_entropy(
    X: np.ndarray,
    normalize: bool = True
) -> Tuple[float, float]:
    """
    Compute spectral entropy from singular value distribution.
    
    S = -Σ pᵢ log(pᵢ) where pᵢ = λᵢ/Σλⱼ
    
    Parameters
    ----------
    X : np.ndarray, shape (N, d)
        Belief matrix with N agents and d-dimensional states
    normalize : bool, default=True
        Whether to normalize entropy by max possible value
        
    Returns
    -------
    S_raw : float
        Raw entropy in nats
    S_norm : float
        Normalized entropy in [0, 1]
        - S ≈ 0: Low diversity (rank-1 matrix)
        - S ≈ 1: High diversity (isotropic distribution)
        
    Examples
    --------
    >>> X = np.random.randn(50, 128)
    >>> S_raw, S_norm = compute_spectral_entropy(X)
    >>> print(f"Entropy: {S_norm:.3f}")
    
    Notes
    -----
    This measures the diversity of representational modes, analogous
    to thermodynamic entropy but for information content.
    """
    X = np.asarray(X)
    
    if X.ndim != 2:
        raise ValueError(f"X must be 2D, got shape {X.shape}")
    
    if X.shape[0] < 2:
        return 0.0, 0.0
    
    # Compute singular values
    try:
        _, s, _ = np.linalg.svd(X, full_matrices=False)
    except np.linalg.LinAlgError:
        return 0.0, 0.0
    
    # Convert to probability distribution
    s_squared = s ** 2
    p = s_squared / (s_squared.sum() + 1e-10)
    
    # Shannon entropy
    S_raw = -np.sum(p * np.log(p + 1e-10))
    
    # Normalize by maximum entropy (uniform distribution)
    n_modes = len(s)
    S_max = np.log(n_modes)
    S_norm = S_raw / (S_max + 1e-10)
    
    return float(S_raw), float(np.clip(S_norm, 0.0, 1.0))


def compute_effective_dimensionality(X: np.ndarray) -> float:
    """
    Compute effective dimensionality d_eff = exp(S_raw).
    
    Parameters
    ----------
    X : np.ndarray, shape (N, d)
        Belief matrix
        
    Returns
    -------
    d_eff : float
        Effective number of dimensions in [1, min(N, d)]
        
    Examples
    --------
    >>> X = np.random.randn(50, 128)
    >>> d_eff = compute_effective_dimensionality(X)
    >>> print(f"Effective dimensions: {d_eff:.1f}")
    
    Notes
    -----
    Perplexity-like measure: how many singular values are "active".
    """
    S_raw, _ = compute_spectral_entropy(X)
    d_eff = np.exp(S_raw)
    
    return float(d_eff)


def compute_entropy_rate(
    trajectory: np.ndarray,
    lag: int = 1
) -> float:
    """
    Compute entropy rate (temporal predictability).
    
    h = H(X_t | X_{t-lag}) / H(X_t)
    
    Parameters
    ----------
    trajectory : np.ndarray, shape (T, N, d)
        Time series with T timesteps
    lag : int, default=1
        Time lag for conditional entropy
        
    Returns
    -------
    h : float
        Entropy rate in [0, 1]
        - h ≈ 0: Highly predictable
        - h ≈ 1: Unpredictable (random)
        
    Examples
    --------
    >>> traj = np.random.randn(100, 50, 128)
    >>> h = compute_entropy_rate(traj, lag=1)
    >>> print(f"Predictability: {1-h:.3f}")
    """
    trajectory = np.asarray(trajectory)
    
    if trajectory.ndim != 3:
        raise ValueError(f"trajectory must be 3D (T, N, d), got {trajectory.shape}")
    
    T = trajectory.shape[0]
    if T <= lag:
        return 1.0
    
    # Current states
    X_t = trajectory[lag:].reshape(-1, trajectory.shape[2])
    
    # Previous states
    X_prev = trajectory[:-lag].reshape(-1, trajectory.shape[2])
    
    # Marginal entropy
    H_t, _ = compute_spectral_entropy(X_t)
    
    # Joint entropy (approximate via concatenation)
    X_joint = np.concatenate([X_prev, X_t], axis=1)
    H_joint, _ = compute_spectral_entropy(X_joint)
    
    # Conditional entropy: H(X_t | X_prev) = H(X_t, X_prev) - H(X_prev)
    H_prev, _ = compute_spectral_entropy(X_prev)
    H_cond = H_joint - H_prev
    
    # Normalize
    h = H_cond / (H_t + 1e-10)
    
    return float(np.clip(h, 0.0, 1.0))


def compute_cross_entropy(
    X1: np.ndarray,
    X2: np.ndarray
) -> float:
    """
    Compute cross-entropy between two distributions.
    
    H(X1, X2) = -Σ p₁(i) log(p₂(i))
    
    Parameters
    ----------
    X1 : np.ndarray, shape (N, d)
        First distribution (belief matrix)
    X2 : np.ndarray, shape (M, d)
        Second distribution (belief matrix)
        
    Returns
    -------
    H_cross : float
        Cross-entropy in nats
        
    Notes
    -----
    Useful for measuring distribution mismatch between agent ensembles.
    """
    X1 = np.asarray(X1)
    X2 = np.asarray(X2)
    
    # Get singular value distributions
    try:
        _, s1, _ = np.linalg.svd(X1, full_matrices=False)
        _, s2, _ = np.linalg.svd(X2, full_matrices=False)
    except np.linalg.LinAlgError:
        return np.inf
    
    # Convert to probabilities
    p1 = (s1 ** 2) / (np.sum(s1 ** 2) + 1e-10)
    p2 = (s2 ** 2) / (np.sum(s2 ** 2) + 1e-10)
    
    # Pad to same length
    max_len = max(len(p1), len(p2))
    p1_pad = np.pad(p1, (0, max_len - len(p1)), constant_values=1e-10)
    p2_pad = np.pad(p2, (0, max_len - len(p2)), constant_values=1e-10)
    
    # Cross-entropy
    H_cross = -np.sum(p1_pad * np.log(p2_pad + 1e-10))
    
    return float(H_cross)


def compute_kl_divergence(
    X1: np.ndarray,
    X2: np.ndarray
) -> float:
    """
    Compute KL divergence D_KL(X1 || X2).
    
    D_KL = Σ p₁(i) log(p₁(i) / p₂(i))
    
    Parameters
    ----------
    X1 : np.ndarray, shape (N, d)
        First distribution
    X2 : np.ndarray, shape (M, d)
        Second distribution (reference)
        
    Returns
    -------
    D_kl : float
        KL divergence in nats (≥ 0)
        
    Examples
    --------
    >>> X1 = np.random.randn(50, 128)
    >>> X2 = np.random.randn(50, 128) + 1.0  # Shifted
    >>> D_kl = compute_kl_divergence(X1, X2)
    >>> print(f"Divergence: {D_kl:.3f} nats")
    """
    # KL = H_cross - H
    H_cross = compute_cross_entropy(X1, X2)
    H1, _ = compute_spectral_entropy(X1)
    
    D_kl = H_cross - H1
    
    return float(max(D_kl, 0.0))


def compute_entropy_production(
    trajectory: np.ndarray,
    dt: float = 1.0
) -> np.ndarray:
    """
    Compute entropy production rate along trajectory.
    
    dS/dt ≈ [S(t+dt) - S(t)] / dt
    
    Parameters
    ----------
    trajectory : np.ndarray, shape (T, N, d)
        Time series
    dt : float, default=1.0
        Time step size
        
    Returns
    -------
    dS_dt : np.ndarray, shape (T-1,)
        Entropy production rate at each step
        
    Examples
    --------
    >>> traj = np.random.randn(100, 50, 128)
    >>> dS_dt = compute_entropy_production(traj)
    >>> import matplotlib.pyplot as plt
    >>> plt.plot(dS_dt)
    >>> plt.ylabel('dS/dt')
    
    Notes
    -----
    Positive dS/dt indicates information gain (exploration).
    Negative dS/dt indicates information loss (exploitation/crystallization).
    """
    trajectory = np.asarray(trajectory)
    T = trajectory.shape[0]
    
    if T < 2:
        return np.array([])
    
    # Compute entropy at each timestep
    S_t = np.zeros(T)
    for t in range(T):
        S_raw, _ = compute_spectral_entropy(trajectory[t])
        S_t[t] = S_raw
    
    # Finite difference
    dS_dt = np.diff(S_t) / dt
    
    return dS_dt


def estimate_entropy_from_samples(
    samples: np.ndarray,
    n_bootstrap: int = 100
) -> Tuple[float, float, float]:
    """
    Estimate normalized entropy S with bootstrap CI.
    
    Parameters
    ----------
    samples : np.ndarray, shape (N, d)
        Agent states
    n_bootstrap : int, default=100
        Number of bootstrap resamples
        
    Returns
    -------
    S_mean : float
        Mean entropy estimate
    S_lower : float
        Lower 95% CI
    S_upper : float
        Upper 95% CI
        
    Examples
    --------
    >>> X = np.random.randn(50, 128)
    >>> mean, lower, upper = estimate_entropy_from_samples(X)
    >>> print(f"S = {mean:.3f} (95% CI: [{lower:.3f}, {upper:.3f}])")
    """
    samples = np.asarray(samples)
    N = samples.shape[0]
    
    entropies = []
    for _ in range(n_bootstrap):
        indices = np.random.choice(N, size=N, replace=True)
        X_boot = samples[indices]
        
        _, S_norm = compute_spectral_entropy(X_boot)
        entropies.append(S_norm)
    
    entropies = np.array(entropies)
    
    return (
        float(np.mean(entropies)),
        float(np.percentile(entropies, 2.5)),
        float(np.percentile(entropies, 97.5))
    )
