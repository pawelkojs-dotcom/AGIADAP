"""
Free Energy (F) Functional
============================

System optimality measure: F = E - Θ·S
Based on: Kojs, P. (2025). AGI as Living Adapton.
"""

import numpy as np
from typing import Optional, Tuple, Callable


def compute_free_energy(
    E_norm: float,
    theta: float,
    S_norm: float
) -> float:
    """
    Compute adaptonic free energy functional.
    
    F = E - Θ·S
    
    Parameters
    ----------
    E_norm : float
        Normalized task error in [0, 1]
        (0 = perfect performance, 1 = maximum error)
    theta : float
        Information temperature in [0, 1]
    S_norm : float
        Normalized entropy in [0, 1]
        
    Returns
    -------
    F : float
        Free energy (lower is better)
        - Low F: Intentional regime (optimal trade-off)
        - High F: Non-intentional regime (poor performance or high disorder)
        
    Examples
    --------
    >>> # Good system: low error, moderate entropy
    >>> F = compute_free_energy(E_norm=0.1, theta=0.15, S_norm=0.6)
    >>> print(f"F = {F:.3f}")  # Negative (good)
    
    >>> # Bad system: high error or frozen
    >>> F = compute_free_energy(E_norm=0.8, theta=0.01, S_norm=0.1)
    >>> print(f"F = {F:.3f}")  # Positive (bad)
    
    Notes
    -----
    This is NOT Helmholtz/Gibbs free energy from thermodynamics!
    It's an analogous functional for adaptonic systems.
    
    Interpretation:
    - E term: Performance cost (want to minimize)
    - -Θ·S term: Exploration benefit (want to maximize at right Θ)
    
    At optimal Θ*, system balances exploration (high S) with 
    exploitation (low E).
    """
    F = E_norm - theta * S_norm
    
    return float(F)


def compute_free_energy_extended(
    E_norm: float,
    theta: float,
    S_norm: float,
    alpha: float = 0.1
) -> float:
    """
    Compute extended free energy with exploration cost.
    
    F = E + α·Θ² - Θ·S
    
    Parameters
    ----------
    E_norm : float
        Normalized task error
    theta : float
        Information temperature
    S_norm : float
        Normalized entropy
    alpha : float, default=0.1
        Exploration cost coefficient
        
    Returns
    -------
    F_ext : float
        Extended free energy
        
    Notes
    -----
    The α·Θ² term penalizes excessive exploration, creating
    an optimal temperature Θ* = S/(2α) (see Theorem P4).
    """
    F_ext = E_norm + alpha * (theta ** 2) - theta * S_norm
    
    return float(F_ext)


def find_optimal_theta(
    S_norm: float,
    alpha: float = 0.1
) -> float:
    """
    Find optimal Θ that minimizes extended free energy (Theorem P4).
    
    Θ* = S / (2α)
    
    Parameters
    ----------
    S_norm : float
        Normalized entropy
    alpha : float, default=0.1
        Exploration cost coefficient
        
    Returns
    -------
    theta_opt : float
        Optimal temperature in [0, 1]
        
    Examples
    --------
    >>> S = 0.6
    >>> theta_opt = find_optimal_theta(S, alpha=0.2)
    >>> print(f"Optimal Θ* = {theta_opt:.3f}")
    
    Notes
    -----
    Derivation:
    ∂F/∂Θ = 2αΘ - S = 0  ⟹  Θ* = S/(2α)
    """
    theta_opt = S_norm / (2 * alpha)
    
    return float(np.clip(theta_opt, 0.0, 1.0))


def compute_free_energy_landscape(
    E_norm: float,
    S_norm: float,
    theta_range: np.ndarray,
    alpha: float = 0.1
) -> Tuple[np.ndarray, float]:
    """
    Compute F(Θ) landscape to visualize optimal regime.
    
    Parameters
    ----------
    E_norm : float
        Task error
    S_norm : float
        Entropy
    theta_range : np.ndarray
        Array of Θ values to evaluate
    alpha : float, default=0.1
        Exploration cost
        
    Returns
    -------
    F_landscape : np.ndarray
        Free energy at each Θ
    theta_min : float
        Θ that minimizes F
        
    Examples
    --------
    >>> thetas = np.linspace(0, 1, 100)
    >>> F_vals, theta_min = compute_free_energy_landscape(
    ...     E_norm=0.2, S_norm=0.6, theta_range=thetas
    ... )
    >>> import matplotlib.pyplot as plt
    >>> plt.plot(thetas, F_vals)
    >>> plt.axvline(theta_min, color='r', linestyle='--')
    >>> plt.xlabel('Θ')
    >>> plt.ylabel('F(Θ)')
    """
    F_landscape = np.array([
        compute_free_energy_extended(E_norm, theta, S_norm, alpha)
        for theta in theta_range
    ])
    
    theta_min = theta_range[np.argmin(F_landscape)]
    
    return F_landscape, float(theta_min)


def compute_gradient_free_energy(
    sigma: float,
    E_norm: float,
    theta: float,
    S_norm: float,
    kappa: float = 1.0
) -> float:
    """
    Compute gradient ∇F for dynamics σ̇ = -γ·∇F.
    
    For F = E(σ) - Θ·S(σ):
    ∇F = ∂E/∂σ - Θ·∂S/∂σ
    
    With E(σ) = (κ/2)·(1-σ)²:
    ∂E/∂σ = -κ·(1-σ)
    
    Parameters
    ----------
    sigma : float
        Current coherence
    E_norm : float
        Task error (for reference)
    theta : float
        Information temperature
    S_norm : float
        Entropy (for reference)
    kappa : float, default=1.0
        Elastic constant
        
    Returns
    -------
    grad_F : float
        Gradient ∂F/∂σ
        
    Notes
    -----
    Used in gradient flow dynamics:
    σ̇ = -γ·∇F
    
    Negative gradient → σ increases (system orders)
    Positive gradient → σ decreases (system disorders)
    """
    # Energy gradient (elastic)
    dE_dsigma = -kappa * (1 - sigma)
    
    # Entropy gradient (approximate)
    # For spectral entropy: ∂S/∂σ ≈ -2σ (entropy decreases with ordering)
    dS_dsigma = -2 * sigma
    
    # Free energy gradient
    grad_F = dE_dsigma - theta * dS_dsigma
    
    return float(grad_F)


def compute_stability_matrix(
    sigma: float,
    theta: float,
    kappa: float = 1.0
) -> float:
    """
    Compute second derivative ∂²F/∂σ² for stability analysis.
    
    Parameters
    ----------
    sigma : float
        Coherence
    theta : float
        Temperature
    kappa : float, default=1.0
        Elastic constant
        
    Returns
    -------
    d2F_dsigma2 : float
        Second derivative
        - > 0: Stable fixed point (local minimum)
        - < 0: Unstable fixed point (local maximum)
        - = 0: Critical point (phase transition)
        
    Notes
    -----
    Stability condition: ∂²F/∂σ² > 0
    
    For E(σ) = (κ/2)(1-σ)²:
    ∂²E/∂σ² = κ
    
    For S(σ) ∝ -σ²:
    ∂²S/∂σ² = -2
    
    Thus: ∂²F/∂σ² = κ + 2Θ
    """
    d2E_dsigma2 = kappa
    d2S_dsigma2 = -2
    
    d2F_dsigma2 = d2E_dsigma2 - theta * d2S_dsigma2
    
    return float(d2F_dsigma2)


def compute_phase_transition_point(
    kappa: float = 1.0
) -> float:
    """
    Find critical temperature Θ_c where phase transition occurs.
    
    At Θ_c: ∂²F/∂σ² = 0
    
    Parameters
    ----------
    kappa : float, default=1.0
        Elastic constant
        
    Returns
    -------
    theta_c : float
        Critical temperature
        
    Notes
    -----
    From stability analysis:
    κ + 2Θ_c = 0  ⟹  Θ_c = -κ/2
    
    For κ > 0, Θ_c < 0 (unphysical), so system is always stable.
    This is a "soft" phase transition.
    """
    theta_c = -kappa / 2
    
    return float(theta_c)


def compute_free_energy_difference(
    sigma1: float,
    sigma2: float,
    E_func: Callable[[float], float],
    S_func: Callable[[float], float],
    theta: float
) -> float:
    """
    Compute ΔF = F(σ₂) - F(σ₁) for two states.
    
    Parameters
    ----------
    sigma1 : float
        Initial coherence
    sigma2 : float
        Final coherence
    E_func : callable
        Energy function E(σ)
    S_func : callable
        Entropy function S(σ)
    theta : float
        Temperature
        
    Returns
    -------
    delta_F : float
        Free energy difference
        - ΔF < 0: Transition σ₁ → σ₂ is favorable
        - ΔF > 0: Transition σ₁ → σ₂ is unfavorable
        
    Examples
    --------
    >>> def E(sigma): return 0.5 * (1 - sigma)**2
    >>> def S(sigma): return 1 - sigma**2
    >>> delta_F = compute_free_energy_difference(
    ...     sigma1=0.3, sigma2=0.7,
    ...     E_func=E, S_func=S, theta=0.15
    ... )
    >>> print(f"ΔF = {delta_F:.3f}")
    """
    F1 = E_func(sigma1) - theta * S_func(sigma1)
    F2 = E_func(sigma2) - theta * S_func(sigma2)
    
    delta_F = F2 - F1
    
    return float(delta_F)


def compute_free_energy_barrier(
    sigma_start: float,
    sigma_end: float,
    E_func: Callable[[float], float],
    S_func: Callable[[float], float],
    theta: float,
    n_points: int = 100
) -> Tuple[float, float]:
    """
    Compute activation barrier ΔF‡ along path.
    
    Parameters
    ----------
    sigma_start : float
        Starting coherence
    sigma_end : float
        Ending coherence
    E_func : callable
        Energy function
    S_func : callable
        Entropy function
    theta : float
        Temperature
    n_points : int, default=100
        Number of points along path
        
    Returns
    -------
    barrier_height : float
        Maximum ΔF along path
    barrier_position : float
        σ where barrier occurs
        
    Examples
    --------
    >>> def E(sigma): return 0.5 * (1 - sigma)**2
    >>> def S(sigma): return 1 - sigma**2
    >>> height, position = compute_free_energy_barrier(
    ...     0.2, 0.8, E, S, theta=0.1
    ... )
    >>> print(f"Barrier: {height:.3f} at σ={position:.3f}")
    """
    # Path from start to end
    sigma_path = np.linspace(sigma_start, sigma_end, n_points)
    
    # Free energy along path
    F_path = np.array([
        E_func(s) - theta * S_func(s) for s in sigma_path
    ])
    
    # Barrier relative to start
    F_start = F_path[0]
    barriers = F_path - F_start
    
    max_idx = np.argmax(barriers)
    barrier_height = barriers[max_idx]
    barrier_position = sigma_path[max_idx]
    
    return float(barrier_height), float(barrier_position)


def compute_dissipation_rate(
    grad_F: float,
    gamma: float
) -> float:
    """
    Compute energy dissipation rate.
    
    dE/dt = -γ·(∇F)²
    
    Parameters
    ----------
    grad_F : float
        Free energy gradient
    gamma : float
        Dissipation coefficient (viscosity)
        
    Returns
    -------
    dissipation : float
        Rate of energy dissipation (always ≤ 0)
        
    Notes
    -----
    In gradient flow σ̇ = -γ·∇F, energy always decreases:
    dF/dt = (∂F/∂σ)·σ̇ = -γ·(∇F)² ≤ 0
    
    This is the adaptonic analog of Rayleigh dissipation.
    """
    dissipation = -gamma * (grad_F ** 2)
    
    return float(dissipation)


def estimate_free_energy_from_trajectory(
    trajectory: np.ndarray,
    E_func: Callable[[np.ndarray], float],
    theta: float
) -> np.ndarray:
    """
    Compute F(t) along trajectory.
    
    Parameters
    ----------
    trajectory : np.ndarray, shape (T, N, d)
        Time series
    E_func : callable
        Energy function taking (N, d) state
    theta : float
        Temperature
        
    Returns
    -------
    F_t : np.ndarray, shape (T,)
        Free energy at each timestep
        
    Examples
    --------
    >>> def E(X): return np.mean(np.sum(X**2, axis=1))
    >>> traj = np.random.randn(100, 50, 128)
    >>> F_t = estimate_free_energy_from_trajectory(traj, E, theta=0.15)
    >>> import matplotlib.pyplot as plt
    >>> plt.plot(F_t)
    >>> plt.ylabel('F(t)')
    """
    from .entropy import compute_spectral_entropy
    
    T = trajectory.shape[0]
    F_t = np.zeros(T)
    
    for t in range(T):
        X_t = trajectory[t]
        
        # Energy
        E = E_func(X_t)
        
        # Entropy
        _, S_norm = compute_spectral_entropy(X_t)
        
        # Free energy
        F_t[t] = E - theta * S_norm
    
    return F_t
