"""
Spectral Coherence (σ) Metrics
================================

Order parameter measuring collective alignment in multi-agent systems.
Based on: Kojs, P. (2025). AGI as Living Adapton.
"""

import numpy as np
from typing import Optional, Tuple


def compute_sigma_spectral(
    X: np.ndarray,
    k: Optional[int] = None,
    normalize: bool = True
) -> float:
    """
    Compute spectral coherence σ via singular value decomposition.
    
    σ = λ₁² / Σλᵢ² (leading singular value fraction)
    
    Parameters
    ----------
    X : np.ndarray, shape (N, d)
        Belief matrix with N agents and d-dimensional states
    k : int, optional
        Number of singular values to compute (default: all)
    normalize : bool, default=True
        Whether to normalize rows to unit norm before SVD
        
    Returns
    -------
    sigma : float
        Coherence in [0, 1]
        - σ ≈ 1: Perfect order (all agents aligned)
        - σ ≈ 0: Maximum disorder (agents uncorrelated)
        
    Examples
    --------
    >>> X = np.random.randn(50, 128)
    >>> sigma = compute_sigma_spectral(X)
    >>> print(f"Coherence: {sigma:.3f}")
    
    Notes
    -----
    This is the primary order parameter in adaptonic theory, analogous
    to magnetization in ferromagnetism or Cooper pair density in 
    superconductivity.
    """
    X = np.asarray(X)
    
    if X.ndim != 2:
        raise ValueError(f"X must be 2D, got shape {X.shape}")
    
    if X.shape[0] < 2:
        return 1.0  # Single agent is trivially coherent
    
    # Normalize rows if requested
    if normalize:
        norms = np.linalg.norm(X, axis=1, keepdims=True)
        norms = np.where(norms > 1e-10, norms, 1.0)
        X = X / norms
    
    # Compute singular values
    try:
        if k is not None and k < min(X.shape):
            # Efficient partial SVD
            from scipy.sparse.linalg import svds
            _, s, _ = svds(X, k=k)
            s = np.sort(s)[::-1]
        else:
            # Full SVD
            _, s, _ = np.linalg.svd(X, full_matrices=False)
    except np.linalg.LinAlgError:
        return 0.0
    
    # Coherence: leading eigenvalue fraction
    s_squared = s ** 2
    sigma = s_squared[0] / (s_squared.sum() + 1e-10)
    
    return float(np.clip(sigma, 0.0, 1.0))


def compute_participation_ratio(X: np.ndarray, normalize: bool = True) -> float:
    """
    Compute inverse participation ratio (IPR).
    
    IPR = (Σλᵢ²)² / Σλᵢ⁴
    
    Measures effective number of active modes.
    
    Parameters
    ----------
    X : np.ndarray, shape (N, d)
        Belief matrix
    normalize : bool, default=True
        Whether to normalize rows
        
    Returns
    -------
    ipr : float
        Participation ratio in [1, min(N, d)]
        - IPR ≈ 1: Single mode dominates
        - IPR ≈ N: All modes equally active
        
    Examples
    --------
    >>> X = np.random.randn(50, 128)
    >>> ipr = compute_participation_ratio(X)
    >>> print(f"Active modes: {ipr:.1f} / 50")
    """
    X = np.asarray(X)
    
    if normalize:
        norms = np.linalg.norm(X, axis=1, keepdims=True)
        norms = np.where(norms > 1e-10, norms, 1.0)
        X = X / norms
    
    try:
        _, s, _ = np.linalg.svd(X, full_matrices=False)
    except np.linalg.LinAlgError:
        return 1.0
    
    s_squared = s ** 2
    s_fourth = s ** 4
    
    ipr = (s_squared.sum() + 1e-10) ** 2 / (s_fourth.sum() + 1e-10)
    
    return float(np.clip(ipr, 1.0, len(s)))


def compute_coherence_from_covariance(
    cov: np.ndarray,
    method: str = 'spectral'
) -> float:
    """
    Compute coherence directly from covariance matrix.
    
    Parameters
    ----------
    cov : np.ndarray, shape (N, N)
        Covariance matrix
    method : str, default='spectral'
        Method to use:
        - 'spectral': λ₁ / Σλᵢ (eigenvalue fraction)
        - 'trace': tr(cov²) / tr(cov)² (normalized trace)
        
    Returns
    -------
    sigma : float
        Coherence in [0, 1]
    """
    cov = np.asarray(cov)
    
    if cov.ndim != 2 or cov.shape[0] != cov.shape[1]:
        raise ValueError(f"cov must be square, got shape {cov.shape}")
    
    if method == 'spectral':
        try:
            eigvals = np.linalg.eigvalsh(cov)
            eigvals = np.sort(np.abs(eigvals))[::-1]
            sigma = eigvals[0] / (eigvals.sum() + 1e-10)
        except np.linalg.LinAlgError:
            return 0.0
    
    elif method == 'trace':
        cov_sq = cov @ cov
        sigma = np.trace(cov_sq) / (np.trace(cov) ** 2 + 1e-10)
    
    else:
        raise ValueError(f"Unknown method: {method}")
    
    return float(np.clip(sigma, 0.0, 1.0))


def compute_sigma_temporal(
    trajectory: np.ndarray,
    window: int = 10
) -> np.ndarray:
    """
    Compute time-varying coherence σ(t) from trajectory.
    
    Parameters
    ----------
    trajectory : np.ndarray, shape (T, N, d)
        Time series with T timesteps, N agents, d dimensions
    window : int, default=10
        Sliding window size for temporal averaging
        
    Returns
    -------
    sigma_t : np.ndarray, shape (T,)
        Coherence at each timestep
        
    Examples
    --------
    >>> traj = np.random.randn(100, 50, 128)
    >>> sigma_t = compute_sigma_temporal(traj, window=5)
    >>> import matplotlib.pyplot as plt
    >>> plt.plot(sigma_t)
    >>> plt.xlabel('Time')
    >>> plt.ylabel('σ(t)')
    """
    trajectory = np.asarray(trajectory)
    
    if trajectory.ndim != 3:
        raise ValueError(f"trajectory must be 3D (T, N, d), got {trajectory.shape}")
    
    T = trajectory.shape[0]
    sigma_t = np.zeros(T)
    
    for t in range(T):
        # Use sliding window
        t_start = max(0, t - window // 2)
        t_end = min(T, t + window // 2 + 1)
        
        # Average over window
        X_window = trajectory[t_start:t_end].reshape(-1, trajectory.shape[2])
        sigma_t[t] = compute_sigma_spectral(X_window)
    
    return sigma_t


def estimate_sigma_from_samples(
    samples: np.ndarray,
    n_bootstrap: int = 100
) -> Tuple[float, float, float]:
    """
    Estimate σ with bootstrap confidence intervals.
    
    Parameters
    ----------
    samples : np.ndarray, shape (N, d)
        Agent states
    n_bootstrap : int, default=100
        Number of bootstrap resamples
        
    Returns
    -------
    sigma_mean : float
        Mean coherence estimate
    sigma_lower : float
        Lower 95% CI
    sigma_upper : float
        Upper 95% CI
        
    Examples
    --------
    >>> X = np.random.randn(50, 128)
    >>> mean, lower, upper = estimate_sigma_from_samples(X)
    >>> print(f"σ = {mean:.3f} (95% CI: [{lower:.3f}, {upper:.3f}])")
    """
    samples = np.asarray(samples)
    N = samples.shape[0]
    
    sigmas = []
    for _ in range(n_bootstrap):
        # Bootstrap resample
        indices = np.random.choice(N, size=N, replace=True)
        X_boot = samples[indices]
        
        sigma = compute_sigma_spectral(X_boot)
        sigmas.append(sigma)
    
    sigmas = np.array(sigmas)
    
    return (
        float(np.mean(sigmas)),
        float(np.percentile(sigmas, 2.5)),
        float(np.percentile(sigmas, 97.5))
    )
