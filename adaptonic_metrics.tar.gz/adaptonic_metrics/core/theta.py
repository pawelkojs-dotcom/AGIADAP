"""
Information Temperature (Θ) Metrics
====================================

Measures exploration vs exploitation balance.
Based on: Kojs, P. (2025). AGI as Living Adapton.
"""

import numpy as np
from typing import Optional, Tuple


def compute_theta_from_probs(
    p: np.ndarray,
    base: Optional[float] = None
) -> float:
    """
    Compute information temperature from probability distribution.
    
    Θ = H(p) / H_max = H(p) / log(N)
    
    where H(p) = -Σ pᵢ log(pᵢ) is Shannon entropy.
    
    Parameters
    ----------
    p : np.ndarray, shape (N,)
        Probability distribution (must sum to 1)
    base : float, optional
        Logarithm base (default: natural log)
        
    Returns
    -------
    theta : float
        Temperature in [0, 1]
        - Θ ≈ 0: Exploitation (deterministic, frozen)
        - Θ ≈ 1: Exploration (uniform, maximum entropy)
        
    Examples
    --------
    >>> # Deterministic (pure exploitation)
    >>> p = np.array([1.0, 0.0, 0.0])
    >>> theta = compute_theta_from_probs(p)
    >>> print(f"Θ = {theta:.3f}")  # ≈ 0.0
    
    >>> # Uniform (maximum exploration)
    >>> p = np.ones(100) / 100
    >>> theta = compute_theta_from_probs(p)
    >>> print(f"Θ = {theta:.3f}")  # ≈ 1.0
    
    Notes
    -----
    This is NOT thermal temperature! It's a dimensionless measure of
    how "spread out" the probability distribution is.
    """
    p = np.asarray(p)
    
    if not np.isclose(p.sum(), 1.0, atol=1e-5):
        raise ValueError(f"p must sum to 1, got {p.sum():.6f}")
    
    if np.any(p < 0):
        raise ValueError("p must be non-negative")
    
    # Shannon entropy
    H = -np.sum(p * np.log(p + 1e-10))
    
    # Change base if requested
    if base is not None:
        H = H / np.log(base)
    
    # Maximum entropy (uniform distribution)
    N = len(p)
    H_max = np.log(N)
    if base is not None:
        H_max = H_max / np.log(base)
    
    # Normalized temperature
    theta = H / (H_max + 1e-10)
    
    return float(np.clip(theta, 0.0, 1.0))


def compute_theta_output_channel(
    probs: np.ndarray,
    axis: int = -1
) -> float:
    """
    Compute average information temperature across output channel.
    
    Θ̄ = mean_i[H(p_i) / log|A|]
    
    Useful for analyzing policy distributions in RL or language models.
    
    Parameters
    ----------
    probs : np.ndarray, shape (..., N)
        Probability distributions (e.g., policy π(a|s) for each state)
    axis : int, default=-1
        Axis over which to compute per-distribution entropy
        
    Returns
    -------
    theta_avg : float
        Average temperature in [0, 1]
        
    Examples
    --------
    >>> # Policy network output (batch_size=32, actions=10)
    >>> probs = np.random.dirichlet(np.ones(10), size=32)
    >>> theta = compute_theta_output_channel(probs)
    >>> print(f"Policy temperature: {theta:.3f}")
    """
    probs = np.asarray(probs)
    
    # Compute entropy for each distribution
    H = -np.sum(probs * np.log(probs + 1e-10), axis=axis)
    
    # Maximum entropy
    N = probs.shape[axis]
    H_max = np.log(N)
    
    # Average normalized entropy
    theta_avg = np.mean(H) / H_max
    
    return float(np.clip(theta_avg, 0.0, 1.0))


def compute_theta_circadian(
    t: float,
    theta_opt: float = 0.15,
    delta_theta: float = 0.05,
    period: float = 100.0
) -> float:
    """
    Compute circadian-modulated temperature.
    
    Θ(t) = Θ_opt + ΔΘ · sin(2π t / T)
    
    Parameters
    ----------
    t : float
        Current time
    theta_opt : float, default=0.15
        Optimal (mean) temperature
    delta_theta : float, default=0.05
        Modulation amplitude
    period : float, default=100.0
        Oscillation period
        
    Returns
    -------
    theta_t : float
        Temperature at time t
        
    Examples
    --------
    >>> # Generate circadian rhythm
    >>> times = np.linspace(0, 200, 1000)
    >>> thetas = [compute_theta_circadian(t) for t in times]
    >>> import matplotlib.pyplot as plt
    >>> plt.plot(times, thetas)
    >>> plt.xlabel('Time')
    >>> plt.ylabel('Θ(t)')
    
    Notes
    -----
    Mimics biological circadian rhythms in exploration/exploitation.
    Useful for avoiding local optima through periodic perturbations.
    """
    theta_t = theta_opt + delta_theta * np.sin(2 * np.pi * t / period)
    
    return float(np.clip(theta_t, 0.0, 1.0))


def compute_theta_adaptive(
    performance: float,
    theta_current: float,
    learning_rate: float = 0.01,
    target_performance: float = 0.8
) -> float:
    """
    Compute adaptively adjusted temperature based on performance.
    
    Θ_{t+1} = Θ_t + η · (target - performance)
    
    Parameters
    ----------
    performance : float
        Current performance metric in [0, 1]
    theta_current : float
        Current temperature
    learning_rate : float, default=0.01
        Adaptation rate η
    target_performance : float, default=0.8
        Target performance level
        
    Returns
    -------
    theta_next : float
        Updated temperature
        
    Notes
    -----
    - If performance < target: Increase Θ (more exploration)
    - If performance > target: Decrease Θ (more exploitation)
    
    Examples
    --------
    >>> theta = 0.15
    >>> for episode in range(100):
    ...     perf = run_episode(theta)
    ...     theta = compute_theta_adaptive(perf, theta)
    """
    error = target_performance - performance
    theta_next = theta_current + learning_rate * error
    
    return float(np.clip(theta_next, 0.0, 1.0))


def estimate_theta_from_actions(
    actions: np.ndarray,
    n_actions: int
) -> float:
    """
    Estimate Θ from observed action sequence.
    
    Parameters
    ----------
    actions : np.ndarray, shape (T,)
        Sequence of discrete actions taken
    n_actions : int
        Total number of possible actions
        
    Returns
    -------
    theta : float
        Estimated temperature from empirical distribution
        
    Examples
    --------
    >>> # Agent mostly exploits action 0
    >>> actions = np.array([0, 0, 0, 1, 0, 2, 0, 0])
    >>> theta = estimate_theta_from_actions(actions, n_actions=10)
    >>> print(f"Estimated Θ = {theta:.3f}")  # Low (exploitative)
    """
    actions = np.asarray(actions)
    
    # Compute empirical distribution
    counts = np.bincount(actions, minlength=n_actions)
    p = counts / (counts.sum() + 1e-10)
    
    # Temperature from empirical distribution
    theta = compute_theta_from_probs(p)
    
    return theta


def compute_theta_boltzmann(
    values: np.ndarray,
    temperature: float
) -> Tuple[np.ndarray, float]:
    """
    Compute Boltzmann distribution and corresponding Θ.
    
    p(a) ∝ exp(Q(a) / T)
    
    Parameters
    ----------
    values : np.ndarray, shape (N,)
        Action values Q(a)
    temperature : float
        Boltzmann temperature T (unnormalized)
        
    Returns
    -------
    probs : np.ndarray, shape (N,)
        Boltzmann probability distribution
    theta : float
        Normalized information temperature Θ
        
    Examples
    --------
    >>> Q = np.array([1.0, 0.5, 0.2])  # Action values
    >>> probs, theta = compute_theta_boltzmann(Q, temperature=0.1)
    >>> print(f"Probs: {probs}")
    >>> print(f"Θ = {theta:.3f}")
    """
    values = np.asarray(values)
    
    # Boltzmann distribution
    if temperature < 1e-10:
        # Greedy (T → 0)
        probs = np.zeros_like(values)
        probs[np.argmax(values)] = 1.0
    else:
        logits = values / temperature
        logits = logits - logits.max()  # Numerical stability
        exp_logits = np.exp(logits)
        probs = exp_logits / exp_logits.sum()
    
    # Normalized temperature
    theta = compute_theta_from_probs(probs)
    
    return probs, theta


def compute_effective_temperature(
    trajectory: np.ndarray,
    dt: float = 1.0
) -> float:
    """
    Estimate effective temperature from trajectory via fluctuation-dissipation.
    
    T_eff ∝ ⟨Δx²⟩ / (2 dt)
    
    Parameters
    ----------
    trajectory : np.ndarray, shape (T, d)
        State trajectory
    dt : float, default=1.0
        Time step size
        
    Returns
    -------
    T_eff : float
        Effective temperature (unnormalized)
        
    Notes
    -----
    This measures the "jitter" in the trajectory, analogous to
    kinetic temperature in physics. Not the same as information
    temperature Θ, but related via fluctuation-dissipation theorem.
    """
    trajectory = np.asarray(trajectory)
    
    if trajectory.shape[0] < 2:
        return 0.0
    
    # Compute displacements
    displacements = np.diff(trajectory, axis=0)
    
    # Mean squared displacement
    msd = np.mean(np.sum(displacements ** 2, axis=1))
    
    # Effective temperature
    T_eff = msd / (2 * dt)
    
    return float(T_eff)


def estimate_theta_from_samples(
    action_samples: np.ndarray,
    n_actions: int,
    n_bootstrap: int = 100
) -> Tuple[float, float, float]:
    """
    Estimate Θ from action samples with bootstrap CI.
    
    Parameters
    ----------
    action_samples : np.ndarray, shape (T,)
        Observed actions
    n_actions : int
        Total number of possible actions
    n_bootstrap : int, default=100
        Number of bootstrap resamples
        
    Returns
    -------
    theta_mean : float
        Mean temperature estimate
    theta_lower : float
        Lower 95% CI
    theta_upper : float
        Upper 95% CI
        
    Examples
    --------
    >>> actions = np.random.choice(10, size=1000)
    >>> mean, lower, upper = estimate_theta_from_samples(actions, n_actions=10)
    >>> print(f"Θ = {mean:.3f} (95% CI: [{lower:.3f}, {upper:.3f}])")
    """
    action_samples = np.asarray(action_samples)
    T = len(action_samples)
    
    thetas = []
    for _ in range(n_bootstrap):
        # Bootstrap resample
        indices = np.random.choice(T, size=T, replace=True)
        actions_boot = action_samples[indices]
        
        theta = estimate_theta_from_actions(actions_boot, n_actions)
        thetas.append(theta)
    
    thetas = np.array(thetas)
    
    return (
        float(np.mean(thetas)),
        float(np.percentile(thetas, 2.5)),
        float(np.percentile(thetas, 97.5))
    )
