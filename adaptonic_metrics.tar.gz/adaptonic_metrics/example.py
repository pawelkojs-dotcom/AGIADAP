"""
Examples of using adaptonic_metrics package.
"""

import numpy as np
from adaptonic_metrics import (
    compute_sigma_spectral,
    compute_spectral_entropy,
    compute_theta_from_probs,
    compute_free_energy
)


def example_basic_metrics():
    """Basic usage of core metrics."""
    print("=" * 60)
    print("EXAMPLE 1: Basic Metrics")
    print("=" * 60)
    
    # Multi-agent belief matrix
    X = np.random.randn(50, 128)  # 50 agents, 128-dim embeddings
    
    # Compute coherence
    sigma = compute_sigma_spectral(X)
    print(f"Coherence σ = {sigma:.3f}")
    
    # Compute entropy
    S_raw, S_norm = compute_spectral_entropy(X)
    print(f"Entropy S = {S_norm:.3f} (raw: {S_raw:.2f} nats)")
    
    # Compute information temperature
    p = np.random.rand(100)
    p = p / p.sum()
    theta = compute_theta_from_probs(p)
    print(f"Temperature Θ = {theta:.3f}")
    
    # Compute free energy
    E_norm = 0.2  # Task error
    F = compute_free_energy(E_norm, theta, S_norm)
    print(f"Free Energy F = {F:.3f}")
    print()


def example_phase_diagram():
    """Visualize σ-Θ phase diagram."""
    print("=" * 60)
    print("EXAMPLE 2: Phase Diagram")
    print("=" * 60)
    
    import matplotlib.pyplot as plt
    
    # Generate grid
    sigmas = np.linspace(0, 1, 50)
    thetas = np.linspace(0, 0.5, 50)
    
    # Compute free energy landscape
    S_norm = 0.6  # Fixed entropy
    E_norm = 0.2  # Fixed task error
    
    F_grid = np.zeros((len(thetas), len(sigmas)))
    for i, theta in enumerate(thetas):
        for j, sigma in enumerate(sigmas):
            F_grid[i, j] = compute_free_energy(E_norm, theta, S_norm)
    
    # Plot
    plt.figure(figsize=(10, 8))
    plt.contourf(sigmas, thetas, F_grid, levels=20, cmap='RdYlGn_r')
    plt.colorbar(label='Free Energy F')
    plt.xlabel('Coherence σ')
    plt.ylabel('Temperature Θ')
    plt.title('Adaptonic Phase Diagram')
    
    # Mark optimal regime
    plt.axvline(0.7, color='red', linestyle='--', label='σ > 0.7 (intentional)')
    plt.axhline(0.15, color='blue', linestyle='--', label='Θ ≈ 0.15 (optimal)')
    plt.legend()
    
    plt.tight_layout()
    plt.savefig('phase_diagram.png', dpi=150)
    print("Saved: phase_diagram.png")
    print()


def example_temporal_evolution():
    """Track metrics over time."""
    print("=" * 60)
    print("EXAMPLE 3: Temporal Evolution")
    print("=" * 60)
    
    from adaptonic_metrics import compute_sigma_temporal
    import matplotlib.pyplot as plt
    
    # Generate trajectory
    T, N, d = 100, 50, 128
    trajectory = np.random.randn(T, N, d)
    
    # Add ordering over time (simulate R3 → R4 transition)
    for t in range(T):
        # Agents gradually align
        alignment_factor = t / T
        mean_state = np.mean(trajectory[t], axis=0)
        trajectory[t] = (1 - alignment_factor) * trajectory[t] + alignment_factor * mean_state
    
    # Compute σ(t)
    sigma_t = compute_sigma_temporal(trajectory, window=5)
    
    # Plot
    plt.figure(figsize=(12, 6))
    plt.plot(sigma_t, linewidth=2)
    plt.axhline(0.7, color='red', linestyle='--', label='Intentionality threshold')
    plt.xlabel('Time step')
    plt.ylabel('Coherence σ(t)')
    plt.title('R3 → R4 Phase Transition')
    plt.legend()
    plt.grid(alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('temporal_evolution.png', dpi=150)
    print("Saved: temporal_evolution.png")
    print()


def example_free_energy_landscape():
    """Visualize F(Θ) landscape."""
    print("=" * 60)
    print("EXAMPLE 4: Free Energy Landscape")
    print("=" * 60)
    
    from adaptonic_metrics import compute_free_energy_landscape, find_optimal_theta
    import matplotlib.pyplot as plt
    
    # Parameters
    E_norm = 0.2
    S_norm = 0.6
    alpha = 0.1
    
    # Compute landscape
    thetas = np.linspace(0, 1, 100)
    F_vals, theta_min = compute_free_energy_landscape(E_norm, S_norm, thetas, alpha)
    
    # Theoretical optimum
    theta_opt = find_optimal_theta(S_norm, alpha)
    
    # Plot
    plt.figure(figsize=(12, 6))
    plt.plot(thetas, F_vals, linewidth=2)
    plt.axvline(theta_opt, color='red', linestyle='--', 
                label=f'Theoretical Θ* = {theta_opt:.3f}')
    plt.axvline(theta_min, color='green', linestyle=':', 
                label=f'Numerical min = {theta_min:.3f}')
    plt.xlabel('Temperature Θ')
    plt.ylabel('Free Energy F(Θ)')
    plt.title(f'Free Energy Landscape (E={E_norm}, S={S_norm})')
    plt.legend()
    plt.grid(alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('free_energy_landscape.png', dpi=150)
    print("Saved: free_energy_landscape.png")
    print(f"Optimal temperature: Θ* = {theta_opt:.3f}")
    print()


def example_bootstrap_ci():
    """Estimate metrics with confidence intervals."""
    print("=" * 60)
    print("EXAMPLE 5: Bootstrap Confidence Intervals")
    print("=" * 60)
    
    from adaptonic_metrics import (
        estimate_sigma_from_samples,
        estimate_entropy_from_samples
    )
    
    # Generate sample
    X = np.random.randn(50, 128)
    
    # Estimate with CI
    sigma_mean, sigma_lower, sigma_upper = estimate_sigma_from_samples(X, n_bootstrap=100)
    S_mean, S_lower, S_upper = estimate_entropy_from_samples(X, n_bootstrap=100)
    
    print(f"Coherence: σ = {sigma_mean:.3f} (95% CI: [{sigma_lower:.3f}, {sigma_upper:.3f}])")
    print(f"Entropy:   S = {S_mean:.3f} (95% CI: [{S_lower:.3f}, {S_upper:.3f}])")
    print()


if __name__ == "__main__":
    # Run all examples
    example_basic_metrics()
    example_bootstrap_ci()
    
    # Visual examples (require matplotlib)
    try:
        import matplotlib.pyplot as plt
        example_phase_diagram()
        example_temporal_evolution()
        example_free_energy_landscape()
        
        print("=" * 60)
        print("All examples completed successfully!")
        print("=" * 60)
    except ImportError:
        print("Skipping visual examples (matplotlib not installed)")
        print("Install with: pip install matplotlib")
