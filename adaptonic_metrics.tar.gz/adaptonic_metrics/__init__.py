"""
Adaptonic Metrics
=================

Professional implementation of adaptonic field metrics for AGI systems.

Based on: Kojs, P. (2025). AGI as Living Adapton: From Molecular Lagoons 
to Intentional Systems.

Core Metrics:
------------
- σ (Sigma): Spectral coherence (order parameter)
- Θ (Theta): Information temperature (exploration/exploitation)
- S (Entropy): Spectral entropy (representational diversity)
- F (Free Energy): System optimality (F = E - Θ·S)

Usage:
------
>>> import numpy as np
>>> from adaptonic_metrics import compute_sigma_spectral, compute_spectral_entropy
>>> 
>>> # Multi-agent belief matrix
>>> X = np.random.randn(50, 128)  # 50 agents, 128-dim
>>> 
>>> # Compute coherence
>>> sigma = compute_sigma_spectral(X)
>>> print(f"Coherence σ = {sigma:.3f}")
>>> 
>>> # Compute entropy
>>> S_raw, S_norm = compute_spectral_entropy(X)
>>> print(f"Entropy S = {S_norm:.3f}")

Installation:
------------
From source:
    pip install -e .

With development tools:
    pip install -e .[dev]

With visualization:
    pip install -e .[vis]
"""

__version__ = "1.0.0"
__author__ = "Paweł Kojs"
__email__ = "pawel.kojs@us.edu.pl"

# Import core metrics
from .core import (
    # Sigma (Coherence)
    compute_sigma_spectral,
    compute_participation_ratio,
    compute_coherence_from_covariance,
    compute_sigma_temporal,
    estimate_sigma_from_samples,
    
    # Entropy
    compute_spectral_entropy,
    compute_effective_dimensionality,
    compute_entropy_rate,
    compute_cross_entropy,
    compute_kl_divergence,
    compute_entropy_production,
    estimate_entropy_from_samples,
    
    # Theta (Temperature)
    compute_theta_from_probs,
    compute_theta_output_channel,
    compute_theta_circadian,
    compute_theta_adaptive,
    estimate_theta_from_actions,
    compute_theta_boltzmann,
    compute_effective_temperature,
    estimate_theta_from_samples,
    
    # Free Energy
    compute_free_energy,
    compute_free_energy_extended,
    find_optimal_theta,
    compute_free_energy_landscape,
    compute_gradient_free_energy,
    compute_stability_matrix,
    compute_phase_transition_point,
    compute_free_energy_difference,
    compute_free_energy_barrier,
    compute_dissipation_rate,
    estimate_free_energy_from_trajectory,
)

__all__ = [
    # Version
    '__version__',
    
    # Sigma (Coherence)
    'compute_sigma_spectral',
    'compute_participation_ratio',
    'compute_coherence_from_covariance',
    'compute_sigma_temporal',
    'estimate_sigma_from_samples',
    
    # Entropy
    'compute_spectral_entropy',
    'compute_effective_dimensionality',
    'compute_entropy_rate',
    'compute_cross_entropy',
    'compute_kl_divergence',
    'compute_entropy_production',
    'estimate_entropy_from_samples',
    
    # Theta (Temperature)
    'compute_theta_from_probs',
    'compute_theta_output_channel',
    'compute_theta_circadian',
    'compute_theta_adaptive',
    'estimate_theta_from_actions',
    'compute_theta_boltzmann',
    'compute_effective_temperature',
    'estimate_theta_from_samples',
    
    # Free Energy
    'compute_free_energy',
    'compute_free_energy_extended',
    'find_optimal_theta',
    'compute_free_energy_landscape',
    'compute_gradient_free_energy',
    'compute_stability_matrix',
    'compute_phase_transition_point',
    'compute_free_energy_difference',
    'compute_free_energy_barrier',
    'compute_dissipation_rate',
    'estimate_free_energy_from_trajectory',
]

# Quick demo
def demo():
    """Run a quick demonstration of core metrics."""
    import numpy as np
    
    print("Adaptonic Metrics Demo")
    print("=" * 60)
    
    # Generate sample data
    X = np.random.randn(50, 128)
    
    # Compute metrics
    sigma = compute_sigma_spectral(X)
    S_raw, S_norm = compute_spectral_entropy(X)
    
    p = np.random.rand(100)
    p = p / p.sum()
    theta = compute_theta_from_probs(p)
    
    E_norm = 0.2
    F = compute_free_energy(E_norm, theta, S_norm)
    
    # Display results
    print(f"\nCoherence σ = {sigma:.3f} ({'high' if sigma > 0.7 else 'moderate' if sigma > 0.4 else 'low'})")
    print(f"Entropy S = {S_norm:.3f} ({'diverse' if S_norm > 0.6 else 'moderate' if S_norm > 0.3 else 'ordered'})")
    print(f"Temperature Θ = {theta:.3f} ({'exploring' if theta > 0.5 else 'balanced' if theta > 0.2 else 'exploiting'})")
    print(f"Free Energy F = {F:.3f} ({'optimal' if F < 0 else 'suboptimal'})")
    print("\n" + "=" * 60)
    print("For more examples, see README.md")


if __name__ == "__main__":
    demo()
