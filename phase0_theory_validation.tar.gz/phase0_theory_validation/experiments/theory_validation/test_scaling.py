"""
Level 2: RG Scaling & Critical Phenomena Tests (< 2 minutes)

Physics-grade analysis of scaling properties.

Run: Pre-release
"""

import numpy as np
import pytest
from typing import List, Tuple

try:
    from adaptonic_metrics.core.sigma import compute_sigma_spectral
    from adaptonic_metrics.core.entropy import compute_spectral_entropy, compute_effective_dimensionality
    from adaptonic_metrics.core.theta import compute_theta_from_probs
    from adaptonic_metrics.core.free_energy import compute_free_energy
except ImportError:
    print("WARNING: adaptonic_metrics not found.")
    raise


# =============================================================================
# RG SCALING - Dimensional Analysis
# =============================================================================

class TestDimensionalScaling:
    """Test if metrics scale correctly with system size."""
    
    def test_sigma_saturation_with_N(self):
        """σ(N) → σ_∞ as N → ∞"""
        d = 64
        alignment = 0.7
        
        N_values = [10, 20, 40, 80, 160]
        sigma_values = []
        
        base = np.random.randn(d)
        base /= np.linalg.norm(base)
        
        for N in N_values:
            noise = np.random.randn(N, d)
            beliefs = alignment * base[None, :] + (1 - alignment) * noise
            
            sigma = compute_sigma_spectral(beliefs)
            sigma_values.append(sigma)
            print(f"   N={N:3d}: σ={sigma:.4f}")
        
        # Test saturation
        for i in range(len(sigma_values) - 1):
            assert sigma_values[i] <= sigma_values[i+1] + 0.02, \
                f"σ not monotonic: N={N_values[i]}→{N_values[i+1]}"
        
        # Convergence
        sigma_late = sigma_values[-3:]
        sigma_std = np.std(sigma_late)
        
        assert sigma_std < 0.05, \
            f"σ not converging: std={sigma_std:.4f}"
        
        print(f"\n✓ Finite-size scaling: σ saturates at σ_∞≈{np.mean(sigma_late):.4f}")
    
    def test_d_eff_scaling_with_dimension(self):
        """d_eff should be independent of embedding dimension"""
        k_intrinsic = 10
        N = 100
        
        d_values = [20, 50, 100, 200]
        d_eff_values = []
        
        for d in d_values:
            U = np.random.randn(N, k_intrinsic)
            V = np.random.randn(k_intrinsic, d)
            X = U @ V
            
            d_eff = compute_effective_dimensionality(X)
            d_eff_values.append(d_eff)
            print(f"   d={d:3d}: d_eff={d_eff:.2f}")
        
        d_eff_mean = np.mean(d_eff_values)
        d_eff_std = np.std(d_eff_values)
        
        assert abs(d_eff_mean - k_intrinsic) < 5, \
            f"d_eff={d_eff_mean:.1f} far from k={k_intrinsic}"
        
        assert d_eff_std < 3, \
            f"d_eff unstable: std={d_eff_std:.2f}"
        
        print(f"\n✓ Dimensional scaling: d_eff≈{d_eff_mean:.1f} invariant")


# =============================================================================
# COARSE-GRAINING
# =============================================================================

class TestCoarseGraining:
    """Test stability under coarse-graining (Kadanoff RG)."""
    
    def test_sigma_under_block_averaging(self):
        """σ preserved under coarse-graining"""
        N = 100
        d = 64
        alignment = 0.6
        
        base = np.random.randn(d)
        base /= np.linalg.norm(base)
        noise = np.random.randn(N, d)
        beliefs_fine = alignment * base[None, :] + (1 - alignment) * noise
        
        sigma_fine = compute_sigma_spectral(beliefs_fine)
        
        # Coarse-grain: block size = 5
        block_size = 5
        N_coarse = N // block_size
        beliefs_coarse = np.zeros((N_coarse, d))
        
        for i in range(N_coarse):
            block = beliefs_fine[i*block_size:(i+1)*block_size]
            beliefs_coarse[i] = block.mean(axis=0)
        
        sigma_coarse = compute_sigma_spectral(beliefs_coarse)
        
        print(f"   σ_fine  = {sigma_fine:.4f} (N={N})")
        print(f"   σ_coarse = {sigma_coarse:.4f} (N={N_coarse})")
        print(f"   Δσ = {abs(sigma_fine - sigma_coarse):.4f}")
        
        assert abs(sigma_fine - sigma_coarse) < 0.15, \
            f"σ not stable: Δσ={abs(sigma_fine - sigma_coarse):.4f}"
        
        print(f"\n✓ Coarse-graining stability: σ preserved")


# =============================================================================
# CRITICAL SCALING
# =============================================================================

class TestCriticalScaling:
    """Test for critical behavior near transitions."""
    
    def test_sigma_critical_exponent(self):
        """σ(γ) should show transition"""
        N = 50
        d = 64
        
        gamma_values = np.linspace(0.5, 1.5, 20)
        sigma_values = []
        
        for gamma in gamma_values:
            alignment = np.tanh(gamma - 0.5)
            
            base = np.random.randn(d)
            base /= np.linalg.norm(base)
            beliefs = alignment * base[None, :] + (1 - alignment) * np.random.randn(N, d)
            
            sigma = compute_sigma_spectral(beliefs)
            sigma_values.append(sigma)
        
        dsigma = np.gradient(sigma_values, gamma_values)
        transition_idx = np.argmax(dsigma)
        gamma_c = gamma_values[transition_idx]
        
        print(f"   Transition near γ_c ≈ {gamma_c:.3f}")
        print(f"   Max slope: dσ/dγ = {dsigma[transition_idx]:.3f}")
        
        assert dsigma[transition_idx] > 0.5, \
            f"No clear transition: max(dσ/dγ) = {dsigma[transition_idx]:.3f}"
        
        print(f"\n✓ Critical scaling: Transition at γ_c ≈ {gamma_c:.3f}")


def test_scaling_summary():
    """Summary of scaling tests."""
    print("\n" + "="*60)
    print("LEVEL 2: RG SCALING & CRITICAL PHENOMENA")
    print("="*60)
    print("✓ Finite-size scaling: σ(N) saturates")
    print("✓ Dimensional invariance: d_eff stable")
    print("✓ Coarse-graining: σ preserved under RG")
    print("✓ Critical scaling: Transition detected")
    print("\nStatus: Metrics exhibit RG-like behavior")
    print("="*60)
