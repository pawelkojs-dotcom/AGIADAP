# Phase 0: Deep Theory Validation
**Adaptonic Metrics Implementation Fidelity**

## Purpose

Phase 0 weryfikuje zgodność implementacji metryk (σ, Θ, S, F) z teorią KERNEL_AGI na poziomie czysto matematycznym, **przed** jakimkolwiek użyciem w modelach czy zadaniach.

**NIE testujemy:**
- Jakości modeli (H_GEN_1)
- Intentionalności AGI (Campaign #3)
- Wydajności na danych

**TESTUJEMY:**
- Czy kod implementuje teorię (fidelity)
- Czy teoria jest spójna (paradoxes)
- Czy metryki skalują poprawnie (RG)
- Czy F ma właściwą strukturę (topology)

---

## Philosophy: Deductive Validation

Nie: Data → Pattern → Model (indukcja)  
Tak: Theory → Predictions → Tests (dedukcja)

Kolejność:
1. **KERNEL_AGI** definiuje σ, Θ, S, F
2. **core/** implementuje numerycznie
3. **Phase 0** weryfikuje zgodność ← TERAZ TU JESTEŚMY
4. **Phase 1** testuje na training (H_GEN_1)
5. **Phase 2** testuje na inference (Campaign #3)

---

## Test Levels

### Level 0: Axioms (< 5 seconds)
**File:** `test_axioms.py`

Podstawowe własności:
- σ, Θ, S ∈ [0, 1]
- Brak NaN/Inf
- Limity deterministyczne/uniform
- Type correctness

**Run:** CI/CD (każdy commit)

---

### Level 1: Fidelity (< 30 seconds)
**File:** `test_fidelity.py`

Zgodność z KERNEL_AGI:
- σ → 1 (perfect order)
- σ → 0 (maximum disorder)
- Monotonicity with alignment
- Rotation invariance
- Θ temperature behavior
- S entropy axioms
- F minimum structure

**Run:** Every PR

---

### Level 2: Scaling (< 2 minutes)
**File:** `test_scaling.py`

RG & Critical Phenomena:
- Finite-size scaling: σ(N) → σ_∞
- Coarse-graining stability (Kadanoff)
- Critical exponents: σ ∝ |γ - γ_c|^β
- Dimensional invariance: d_eff stable
- Computational complexity: O(d³) acceptable?

**Run:** Pre-release

---

### Level 3: Topology (< 5 minutes)
**File:** `test_topology.py`

Global Structure:
- Morse theory: Critical points classification
- Basin analysis: Volume, connectivity
- Gradient flow: Convergence to minimum
- Separatrix: Boundary location
- Hessian: Curvature at minimum

**Run:** Major releases

---

## Quick Start

```bash
# Fast check (CI/CD)
pytest experiments/theory_validation/test_axioms.py -v

# Full validation
pytest experiments/theory_validation/ -v -s

# With visualizations
./experiments/theory_validation/run_full_validation.sh
```

---

## When is Phase 0 "DONE"?

Phase 0 is complete when:

✅ All Level 0-1 tests pass (required)  
✅ Level 2 shows no numerical explosions > 10% (required)  
✅ Level 3 confirms F topology (recommended)  
✅ No Crisis #1-4 symptoms detected  
✅ Metrics are mathematically stable

**Decision Gate 1:** GO → Phase 1 (H_GEN_1)

---

## File Descriptions

### `test_axioms.py`
Fastest tests, basic properties.
- Bounds checking
- NaN/Inf detection
- Type safety

### `test_fidelity.py`
Core implementation correctness.
- Each metric (σ,Θ,S,F) tested independently
- Limits, monotonicity, invariances
- ~30 test cases

### `test_scaling.py`
Physics-grade scaling analysis.
- RG flow under coarse-graining
- Critical scaling near transitions
- Dimensional analysis
- Computational feasibility: O(d³) vs approximations

### `test_topology.py`
Global structure of F landscape.
- Morse theory: Count/classify critical points
- Basin structure: Volume, connectivity
- Gradient dynamics: Flow to minimum
- Curvature: Hessian eigenvalues

### `visualizations/`
Plot generation (not for CI).
- F landscape 2D/3D
- Phase diagrams
- RG flow evolution
- Used for documentation/papers

---

## Integration with TRL

**TRL 3-4 (Current):**
- Level 0-1 must pass
- Level 2-3 exploratory

**TRL 4-5 (Before H_GEN_1):**
- Level 0-2 must pass
- Level 3 documented

**TRL 5-6 (Before AGI):**
- Level 0-3 must pass
- No regressions vs Campaign #3

---

## Phase 0 → Phase 1 → Phase 2

```
PHASE 0: THEORY VALIDATION
    ↓ (σ/F mathematically verified)
PHASE 1: H_GEN_1 TRAINING
    ↓ (σ/F verified on learning dynamics)
PHASE 2: CAMPAIGN #3/#4 INFERENCE
    ↓ (σ/F verified on intentionality)
DEPLOYMENT
```

Phase 0 zapobiega:
- Fałszywym wnioskom empirycznym (theory-first)
- Obwinianiu teorii za błędy implementacji
- Regresjom względem zwalidowanych metryk

---

## Technical Details

### Computational Complexity
- σ_spectral: O(min(Nd², N²d)) via SVD
- For d=1536, N=100: ~1.5s per computation
- Batch optimization possible via incremental SVD

### Numerical Stability
- All metrics tested with condition numbers > 10¹⁵
- Eigenvalue thresholds: λ > 10⁻¹⁰
- Normalized metrics: [0,1] to avoid overflow

### Known Limitations
- **Eigenvalue Mirage** (Crisis #1): σ measures coherence, not quality
  → Solution: Use F = E - ΘS, not σ alone
- **O(d³) scaling** (Crisis #3): May need approximations for d > 2048
  → Solution: Random projections or Nyström method

---

## Related Documentation

- `KERNEL_AGI.md` - Theoretical foundations
- `THEORY_VALIDATION_PROTOCOL.md` - Methodology
- `ADR-2025-11-20` - Spectral metrics adoption
- `INVARIANTS_AGI.md` - Mathematical constraints

---

## Acknowledgments

Theory validation approach inspired by:
- Wilson (1971): Renormalization Group methods
- Landau (1937): Phase transition theory
- Morse (1925): Topological analysis of critical points
- Popper (1959): Deductive scientific method
