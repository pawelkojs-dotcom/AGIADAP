"""
Level 0: Axiom Tests (< 5 seconds)

Fast sanity checks of basic properties.
Run on every commit (CI/CD).

Purpose: Catch obvious bugs before deeper analysis.
"""

import numpy as np
import pytest

# NOTE: These imports assume adaptonic_metrics is installed
# For standalone testing, adjust paths or install package
try:
    from adaptonic_metrics.core.sigma import compute_sigma_spectral
    from adaptonic_metrics.core.entropy import compute_spectral_entropy, compute_effective_dimensionality
    from adaptonic_metrics.core.theta import compute_theta_from_probs, compute_theta_output_channel
    from adaptonic_metrics.core.free_energy import compute_free_energy
except ImportError:
    print("WARNING: adaptonic_metrics not found. Install package or adjust PYTHONPATH.")
    print("Example: pip install -e /path/to/adaptonic_metrics")
    raise


class TestBasicAxioms:
    """Fastest possible checks - basic axioms."""
    
    def test_sigma_bounded(self):
        """σ ∈ [0, 1]"""
        X = np.random.randn(20, 30)
        sigma = compute_sigma_spectral(X)
        assert 0.0 <= sigma <= 1.0, f"σ={sigma:.3f} out of bounds"
    
    def test_theta_bounded(self):
        """Θ ∈ [0, 1]"""
        p = np.random.rand(50)
        p = p / p.sum()
        theta = compute_theta_from_probs(p)
        assert 0.0 <= theta <= 1.0, f"Θ={theta:.3f} out of bounds"
    
    def test_entropy_bounded(self):
        """S_norm ∈ [0, 1]"""
        X = np.random.randn(20, 30)
        S_raw, S_norm = compute_spectral_entropy(X)
        assert S_raw >= 0.0, f"S_raw={S_raw:.3f} negative"
        assert 0.0 <= S_norm <= 1.0, f"S_norm={S_norm:.3f} out of bounds"
    
    def test_no_nans_infs(self):
        """No NaN/Inf in normal operation"""
        X = np.random.randn(20, 30)
        p = np.random.rand(50)
        p = p / p.sum()
        
        sigma = compute_sigma_spectral(X)
        S_raw, S_norm = compute_spectral_entropy(X)
        theta = compute_theta_from_probs(p)
        F = compute_free_energy(0.5, theta, S_norm)
        
        assert np.isfinite(sigma), "σ not finite"
        assert np.isfinite(S_raw), "S_raw not finite"
        assert np.isfinite(S_norm), "S_norm not finite"
        assert np.isfinite(theta), "Θ not finite"
        assert np.isfinite(F), "F not finite"


class TestLimitBehavior:
    """Test limiting cases (deterministic/uniform)."""
    
    def test_theta_deterministic(self):
        """Θ → 0 for deterministic distribution"""
        p = np.zeros(100)
        p[0] = 1.0
        theta = compute_theta_from_probs(p)
        assert theta < 0.05, f"Deterministic: Θ={theta:.3f} should be ≈0"
    
    def test_theta_uniform(self):
        """Θ → 1 for uniform distribution"""
        p = np.ones(100) / 100.0
        theta = compute_theta_from_probs(p)
        assert theta > 0.95, f"Uniform: Θ={theta:.3f} should be ≈1"


def test_axioms_summary():
    """Summary test."""
    print("\n" + "="*60)
    print("LEVEL 0: AXIOM VALIDATION")
    print("="*60)
    print("✓ All metrics bounded [0,1]")
    print("✓ No NaN/Inf")
    print("✓ Limit behaviors correct")
    print("\nStatus: Basic axioms satisfied")
    print("="*60)
