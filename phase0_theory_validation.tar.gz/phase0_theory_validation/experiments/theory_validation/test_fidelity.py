"""
Level 1: Implementation Fidelity Tests (< 30 seconds)

Verify that core implementations faithfully realize KERNEL_AGI theory.

Run: Every PR
"""

import numpy as np
import pytest

try:
    from adaptonic_metrics.core.sigma import compute_sigma_spectral
    from adaptonic_metrics.core.entropy import compute_spectral_entropy, compute_effective_dimensionality
    from adaptonic_metrics.core.theta import compute_theta_from_probs, compute_theta_output_channel
    from adaptonic_metrics.core.free_energy import compute_free_energy
except ImportError:
    print("WARNING: adaptonic_metrics not found. Install package or adjust PYTHONPATH.")
    raise


# =============================================================================
# SIGMA FIDELITY
# =============================================================================

class TestSigmaFidelity:
    """σ_spectral must implement KERNEL σ field."""
    
    def test_perfect_order_limit(self):
        """KERNEL: σ → 1 for perfect consensus"""
        v = np.random.randn(64)
        X = np.tile(v, (20, 1)) + np.random.randn(20, 64) * 1e-6
        
        sigma = compute_sigma_spectral(X)
        assert sigma > 0.95, f"Perfect order: σ={sigma:.3f} should be ≈1"
    
    def test_maximum_disorder_limit(self):
        """KERNEL: σ → 0 for orthogonal vectors"""
        Q, _ = np.linalg.qr(np.random.randn(128, 128))
        X = Q[:20, :]
        
        sigma = compute_sigma_spectral(X)
        assert sigma < 0.3, f"Max disorder: σ={sigma:.3f} should be ≈0"
    
    def test_monotonic_with_alignment(self):
        """KERNEL: σ increases with alignment"""
        d, n = 64, 20
        base = np.random.randn(d) / np.sqrt(d)
        
        sigmas = []
        for alignment in [0.1, 0.5, 0.9]:
            X = alignment * base + (1-alignment) * np.random.randn(n, d)
            sigmas.append(compute_sigma_spectral(X))
        
        assert all(sigmas[i] < sigmas[i+1] + 0.1 for i in range(len(sigmas)-1)), \
            f"Not monotonic: {sigmas}"
    
    def test_rotation_invariant(self):
        """KERNEL: σ invariant to rotations"""
        X = np.random.randn(30, 50)
        Q, _ = np.linalg.qr(np.random.randn(50, 50))
        
        sigma1 = compute_sigma_spectral(X)
        sigma2 = compute_sigma_spectral(X @ Q)
        
        assert abs(sigma1 - sigma2) < 0.05, \
            f"Not rotation invariant: {sigma1:.3f} vs {sigma2:.3f}"
    
    def test_scale_invariant(self):
        """KERNEL: σ invariant to scaling"""
        X = np.random.randn(30, 50)
        
        sigma1 = compute_sigma_spectral(X)
        sigma2 = compute_sigma_spectral(X * 10.0)
        sigma3 = compute_sigma_spectral(X * 0.1)
        
        assert abs(sigma1 - sigma2) < 0.01, f"Not scale invariant: {sigma1:.3f} vs {sigma2:.3f}"
        assert abs(sigma1 - sigma3) < 0.01, f"Not scale invariant: {sigma1:.3f} vs {sigma3:.3f}"


# =============================================================================
# THETA FIDELITY
# =============================================================================

class TestThetaFidelity:
    """Θ must behave like information temperature."""
    
    def test_deterministic_limit(self):
        """KERNEL: Θ → 0 for deterministic"""
        p = np.zeros(100)
        p[0] = 1.0
        
        theta = compute_theta_from_probs(p)
        assert theta < 0.05, f"Deterministic: Θ={theta:.3f} should be ≈0"
    
    def test_uniform_limit(self):
        """KERNEL: Θ → 1 for uniform"""
        p = np.ones(100) / 100
        
        theta = compute_theta_from_probs(p)
        assert theta > 0.95, f"Uniform: Θ={theta:.3f} should be ≈1"
    
    def test_monotonic_with_temperature(self):
        """KERNEL: Θ increases with softmax temperature"""
        logits = np.random.randn(100, 50)
        
        def softmax(x, T):
            x = (x - x.max(axis=-1, keepdims=True)) / T
            return np.exp(x) / np.exp(x).sum(axis=-1, keepdims=True)
        
        thetas = []
        for T in [0.1, 0.5, 2.0]:
            probs = softmax(logits, T)
            theta = compute_theta_output_channel(probs)
            thetas.append(theta)
        
        assert all(thetas[i] <= thetas[i+1] + 0.05 for i in range(len(thetas)-1)), \
            f"Not monotonic: {thetas}"


# =============================================================================
# ENTROPY FIDELITY
# =============================================================================

class TestEntropyFidelity:
    """S must satisfy Shannon entropy axioms."""
    
    def test_rank1_minimum(self):
        """KERNEL: S → 0 for rank-1 matrix"""
        v = np.random.randn(128)
        X = np.outer(np.random.randn(30), v)
        
        _, S_norm = compute_spectral_entropy(X)
        assert S_norm < 0.1, f"Rank-1: S={S_norm:.3f} should be ≈0"
    
    def test_isotropic_maximum(self):
        """KERNEL: S → 1 for isotropic spectrum"""
        X = np.eye(64) + np.random.randn(64, 64) * 0.01
        
        _, S_norm = compute_spectral_entropy(X)
        assert S_norm > 0.9, f"Isotropic: S={S_norm:.3f} should be ≈1"
    
    def test_d_eff_interpretation(self):
        """KERNEL: d_eff = exp(S_raw)"""
        k = 10
        strong = np.random.randn(50, k)
        weak = np.random.randn(50, 90) * 0.01
        X = np.hstack([strong, weak])
        
        d_eff = compute_effective_dimensionality(X)
        assert k * 0.5 < d_eff < k * 2, \
            f"d_eff={d_eff:.1f} far from expected k={k}"


# =============================================================================
# FREE ENERGY FIDELITY
# =============================================================================

class TestFreeEnergyFidelity:
    """F = E - ΘS must have correct structure."""
    
    def test_decreases_with_lower_error(self):
        """KERNEL: ∂F/∂E > 0"""
        theta, S = 0.5, 0.7
        
        F_values = [compute_free_energy(E, theta, S) for E in [0.1, 0.5, 0.9]]
        
        assert F_values[0] < F_values[1] < F_values[2], \
            f"F not monotonic in E: {F_values}"
    
    def test_minimum_in_intentional_regime(self):
        """KERNEL: F minimized at low E, moderate Θ, high S"""
        F_good = compute_free_energy(0.1, 0.4, 0.7)
        F_bad_error = compute_free_energy(0.8, 0.4, 0.7)
        F_bad_random = compute_free_energy(0.1, 0.9, 0.9)
        F_bad_rigid = compute_free_energy(0.1, 0.1, 0.2)
        
        assert F_good < min(F_bad_error, F_bad_random, F_bad_rigid), \
            f"F minimum not in intentional regime: {F_good:.3f}"
    
    def test_gradient_directions(self):
        """KERNEL: ∇F points toward intentional regime"""
        # Analytical gradients for F = E - ΘS
        # ∂F/∂E = 1 (always positive - increase E increases F)
        # ∂F/∂Θ = -S (negative for S>0)
        # ∂F/∂S = -Θ (negative for Θ>0)
        
        E, theta, S = 0.5, 0.5, 0.5
        eps = 1e-4
        
        # Test ∂F/∂E > 0
        F0 = compute_free_energy(E, theta, S)
        F_plus_E = compute_free_energy(E + eps, theta, S)
        dF_dE = (F_plus_E - F0) / eps
        assert dF_dE > 0.9, f"∂F/∂E = {dF_dE:.3f} should be ≈1"
        
        # Test ∂F/∂Θ < 0 (for S > 0)
        F_plus_theta = compute_free_energy(E, theta + eps, S)
        dF_dtheta = (F_plus_theta - F0) / eps
        expected_dF_dtheta = -S
        assert abs(dF_dtheta - expected_dF_dtheta) < 0.01, \
            f"∂F/∂Θ = {dF_dtheta:.3f}, expected {expected_dF_dtheta:.3f}"


# =============================================================================
# SUMMARY
# =============================================================================

def test_fidelity_summary():
    """Summary of fidelity validation."""
    print("\n" + "="*60)
    print("LEVEL 1: IMPLEMENTATION FIDELITY")
    print("="*60)
    print("✓ σ implements KERNEL σ field")
    print("✓ Θ implements KERNEL Θ field")
    print("✓ S implements KERNEL S field")
    print("✓ F implements KERNEL F functional")
    print("\nStatus: Implementation faithful to theory")
    print("="*60)
