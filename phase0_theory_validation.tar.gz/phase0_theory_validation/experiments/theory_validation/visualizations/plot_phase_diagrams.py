"""
Visualization Tools for Theory Validation

Generate publication-quality plots of F landscape, phase diagrams, RG flow.
"""

import numpy as np
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D

try:
    from adaptonic_metrics.core.free_energy import compute_free_energy
    from adaptonic_metrics.core.sigma import compute_sigma_spectral
    from adaptonic_metrics.core.entropy import compute_spectral_entropy
except ImportError:
    print("WARNING: adaptonic_metrics not found.")
    print("Visualizations will use mock functions.")
    
    def compute_free_energy(E, theta, S):
        return E - theta * S
    
    def compute_sigma_spectral(X):
        U, s, Vt = np.linalg.svd(X, full_matrices=False)
        s_normalized = s / (s.sum() + 1e-12)
        return s_normalized[0] if len(s_normalized) > 0 else 0.0
    
    def compute_spectral_entropy(X):
        U, s, Vt = np.linalg.svd(X, full_matrices=False)
        s_normalized = s / (s.sum() + 1e-12)
        S_raw = -np.sum(s_normalized * np.log(s_normalized + 1e-12))
        S_max = np.log(len(s_normalized))
        S_norm = S_raw / S_max if S_max > 0 else 0.0
        return S_raw, S_norm


def plot_F_landscape_2D(save_path='F_landscape_2D.png'):
    """Plot F(E, Θ) heatmap at fixed S."""
    fig, axes = plt.subplots(1, 3, figsize=(15, 4))
    
    S_values = [0.3, 0.5, 0.7]
    
    for ax, S_fixed in zip(axes, S_values):
        E_range = np.linspace(0.0, 1.0, 100)
        theta_range = np.linspace(0.0, 1.0, 100)
        E_grid, Theta_grid = np.meshgrid(E_range, theta_range)
        
        F_grid = np.zeros_like(E_grid)
        for i in range(len(E_range)):
            for j in range(len(theta_range)):
                F_grid[j, i] = compute_free_energy(E_grid[j, i], Theta_grid[j, i], S_fixed)
        
        im = ax.contourf(E_grid, Theta_grid, F_grid, levels=20, cmap='RdYlBu_r')
        ax.contour(E_grid, Theta_grid, F_grid, levels=10, colors='k', alpha=0.3, linewidths=0.5)
        
        min_idx = np.unravel_index(np.argmin(F_grid), F_grid.shape)
        E_min = E_grid[min_idx]
        Theta_min = Theta_grid[min_idx]
        ax.plot(E_min, Theta_min, 'r*', markersize=15, label='Global minimum')
        
        ax.set_xlabel('E (task error)', fontsize=12)
        ax.set_ylabel('Θ (information temperature)', fontsize=12)
        ax.set_title(f'F landscape (S={S_fixed:.1f})', fontsize=13)
        ax.legend()
        
        plt.colorbar(im, ax=ax, label='F')
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"Saved: {save_path}")
    plt.close()


def plot_F_landscape_3D(save_path='F_landscape_3D.png'):
    """Plot 3D surface of F(E, Θ)."""
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    
    E_range = np.linspace(0.0, 1.0, 50)
    theta_range = np.linspace(0.0, 1.0, 50)
    E_grid, Theta_grid = np.meshgrid(E_range, theta_range)
    
    S_fixed = 0.5
    F_grid = np.zeros_like(E_grid)
    for i in range(len(E_range)):
        for j in range(len(theta_range)):
            F_grid[j, i] = compute_free_energy(E_grid[j, i], Theta_grid[j, i], S_fixed)
    
    surf = ax.plot_surface(E_grid, Theta_grid, F_grid, 
                           cmap=cm.coolwarm, alpha=0.8,
                           linewidth=0, antialiased=True)
    
    min_idx = np.unravel_index(np.argmin(F_grid), F_grid.shape)
    E_min = E_grid[min_idx]
    Theta_min = Theta_grid[min_idx]
    F_min = F_grid[min_idx]
    ax.scatter([E_min], [Theta_min], [F_min], c='r', s=100, marker='*', label='Minimum')
    
    ax.set_xlabel('E (task error)', fontsize=12)
    ax.set_ylabel('Θ (temperature)', fontsize=12)
    ax.set_zlabel('F (free energy)', fontsize=12)
    ax.set_title(f'F(E, Θ) landscape (S={S_fixed})', fontsize=14)
    
    plt.colorbar(surf, ax=ax, shrink=0.5, aspect=5)
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"Saved: {save_path}")
    plt.close()


def plot_phase_diagram(save_path='phase_diagram.png'):
    """Plot phase diagram: intentional vs non-intentional regions."""
    fig, ax = plt.subplots(figsize=(8, 6))
    
    n = 100
    E_range = np.linspace(0.0, 1.0, n)
    theta_range = np.linspace(0.0, 1.0, n)
    E_grid, Theta_grid = np.meshgrid(E_range, theta_range)
    
    S_fixed = 0.7
    F_threshold = 0.5
    
    F_grid = np.zeros_like(E_grid)
    for i in range(n):
        for j in range(n):
            F_grid[j, i] = compute_free_energy(E_grid[j, i], Theta_grid[j, i], S_fixed)
    
    intentional_mask = (F_grid < F_threshold).astype(int)
    
    ax.contourf(E_grid, Theta_grid, intentional_mask, 
                levels=[0, 0.5, 1], colors=['lightcoral', 'lightgreen'],
                alpha=0.6)
    ax.contour(E_grid, Theta_grid, F_grid, levels=[F_threshold], 
               colors='k', linewidths=2, linestyles='--')
    
    ax.text(0.7, 0.5, 'Non-Intentional\n(High F)', fontsize=12, ha='center')
    ax.text(0.15, 0.5, 'Intentional\n(Low F)', fontsize=12, ha='center')
    
    ax.set_xlabel('E (task error)', fontsize=12)
    ax.set_ylabel('Θ (exploration)', fontsize=12)
    ax.set_title(f'Phase Diagram (S={S_fixed}, F_crit={F_threshold})', fontsize=14)
    ax.grid(alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"Saved: {save_path}")
    plt.close()


def plot_RG_flow(save_path='RG_flow.png'):
    """Plot RG flow: coarse-graining evolution."""
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    
    N_initial = 1000
    block_sizes = [2, 4, 8, 16, 32]
    
    sigma_evolution = []
    S_evolution = []
    
    np.random.seed(42)
    base = np.random.randn(64)
    base /= np.linalg.norm(base)
    
    for block_size in block_sizes:
        N_coarse = N_initial // block_size
        
        beliefs = 0.7 * base[None, :] + 0.3 * np.random.randn(N_initial, 64)
        
        beliefs_coarse = np.zeros((N_coarse, 64))
        for i in range(N_coarse):
            beliefs_coarse[i] = beliefs[i*block_size:(i+1)*block_size].mean(axis=0)
        
        sigma = compute_sigma_spectral(beliefs_coarse)
        _, S_norm = compute_spectral_entropy(beliefs_coarse)
        
        sigma_evolution.append(sigma)
        S_evolution.append(S_norm)
    
    RG_steps = range(len(block_sizes))
    
    axes[0].plot(RG_steps, sigma_evolution, 'o-', linewidth=2, markersize=8)
    axes[0].set_xlabel('RG step (coarse-graining level)', fontsize=12)
    axes[0].set_ylabel('σ (coherence)', fontsize=12)
    axes[0].set_title('RG Flow: σ Evolution', fontsize=13)
    axes[0].grid(alpha=0.3)
    axes[0].set_xticks(RG_steps)
    axes[0].set_xticklabels([f'{b}x' for b in block_sizes])
    
    axes[1].plot(RG_steps, S_evolution, 's-', color='orange', linewidth=2, markersize=8)
    axes[1].set_xlabel('RG step (coarse-graining level)', fontsize=12)
    axes[1].set_ylabel('S (entropy)', fontsize=12)
    axes[1].set_title('RG Flow: S Evolution', fontsize=13)
    axes[1].grid(alpha=0.3)
    axes[1].set_xticks(RG_steps)
    axes[1].set_xticklabels([f'{b}x' for b in block_sizes])
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"Saved: {save_path}")
    plt.close()


if __name__ == '__main__':
    """Generate all plots."""
    print("Generating theory validation visualizations...")
    
    plot_F_landscape_2D()
    plot_F_landscape_3D()
    plot_phase_diagram()
    plot_RG_flow()
    
    print("\n✓ All visualizations generated")
