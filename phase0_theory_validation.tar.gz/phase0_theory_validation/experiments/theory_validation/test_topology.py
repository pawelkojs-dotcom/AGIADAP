"""
Level 3: Topological Analysis (< 5 minutes)

Global structure of F landscape - Morse theory, basins, gradient flow.

Run: Major releases
"""

import numpy as np
from scipy.ndimage import label
import pytest

try:
    from adaptonic_metrics.core.free_energy import compute_free_energy
except ImportError:
    print("WARNING: adaptonic_metrics not found.")
    raise


# =============================================================================
# MORSE THEORY
# =============================================================================

class TestMorseTheory:
    """Critical points analysis."""
    
    def test_critical_points_classification(self):
        """Find and classify critical points of F(E, Θ, S)"""
        E_range = np.linspace(0.0, 1.0, 20)
        theta_range = np.linspace(0.0, 1.0, 20)
        S_range = np.linspace(0.0, 1.0, 20)
        
        F_grid = np.zeros((len(E_range), len(theta_range), len(S_range)))
        for i, E in enumerate(E_range):
            for j, theta in enumerate(theta_range):
                for k, S in enumerate(S_range):
                    F_grid[i, j, k] = compute_free_energy(E, theta, S)
        
        critical_points = []
        
        for i in range(1, len(E_range)-1):
            for j in range(1, len(theta_range)-1):
                for k in range(1, len(S_range)-1):
                    val = F_grid[i, j, k]
                    
                    neighbors = [
                        F_grid[i-1, j, k], F_grid[i+1, j, k],
                        F_grid[i, j-1, k], F_grid[i, j+1, k],
                        F_grid[i, j, k-1], F_grid[i, j, k+1],
                    ]
                    
                    if val < min(neighbors):
                        critical_points.append({
                            'type': 'minimum',
                            'coords': (E_range[i], theta_range[j], S_range[k]),
                            'F': val
                        })
        
        minima = [p for p in critical_points if p['type'] == 'minimum']
        
        print(f"   Found {len(minima)} local minima:")
        for m in minima:
            E, theta, S = m['coords']
            print(f"      E={E:.2f}, Θ={theta:.2f}, S={S:.2f} → F={m['F']:.3f}")
        
        assert len(minima) >= 1, "No minimum found"
        
        global_min = min(minima, key=lambda x: x['F'])
        E_min = global_min['coords'][0]
        
        assert E_min < 0.3, f"Minimum at E={E_min:.2f}, expected E<0.3"
        
        print(f"\n✓ Morse theory: Global minimum at E={E_min:.2f}")
    
    def test_gradient_flow_to_minimum(self):
        """Gradient flow should converge to minimum"""
        def grad_F(E, theta, S):
            return np.array([1.0, -S, -theta])
        
        n_tests = 20
        convergence_points = []
        
        for _ in range(n_tests):
            point = np.random.rand(3)
            
            lr = 0.01
            for step in range(1000):
                grad = grad_F(*point)
                point = point - lr * grad
                point = np.clip(point, 0.0, 1.0)
                
                if np.linalg.norm(grad) < 1e-3:
                    break
            
            convergence_points.append(point)
        
        E_final = [p[0] for p in convergence_points]
        E_mean = np.mean(E_final)
        
        print(f"   E_final: {E_mean:.3f} ± {np.std(E_final):.3f}")
        print(f"   {len([e for e in E_final if e < 0.2])}/{n_tests} converged to E<0.2")
        
        assert np.mean([e < 0.3 for e in E_final]) > 0.7, \
            "Gradient flow doesn't converge to intentional regime"
        
        print(f"\n✓ Gradient flow: Converges to low-E basin")


# =============================================================================
# BASIN STRUCTURE
# =============================================================================

class TestBasinStructure:
    """Analyze basin of attraction."""
    
    def test_intentional_basin_volume(self):
        """Estimate volume of intentional basin"""
        n_samples = 10000
        F_threshold = 0.5
        
        samples = np.random.rand(n_samples, 3)
        
        F_values = []
        for sample in samples:
            E, theta, S = sample
            F = compute_free_energy(E, theta, S)
            F_values.append(F)
        
        F_values = np.array(F_values)
        
        n_intentional = np.sum(F_values < F_threshold)
        volume_fraction = n_intentional / n_samples
        
        print(f"   Intentional basin (F < {F_threshold}):")
        print(f"      Volume fraction: {volume_fraction:.1%}")
        print(f"      Count: {n_intentional}/{n_samples}")
        
        assert 0.05 < volume_fraction < 0.5, \
            f"Basin volume unusual: {volume_fraction:.1%}"
        
        print(f"\n✓ Basin volume: {volume_fraction:.1%} of space")
    
    def test_basin_connectivity(self):
        """Test if intentional basin is simply connected"""
        n_points = 15
        E_range = np.linspace(0.0, 1.0, n_points)
        theta_range = np.linspace(0.0, 1.0, n_points)
        S_range = np.linspace(0.0, 1.0, n_points)
        
        F_grid = np.zeros((n_points, n_points, n_points))
        for i, E in enumerate(E_range):
            for j, theta in enumerate(theta_range):
                for k, S in enumerate(S_range):
                    F_grid[i, j, k] = compute_free_energy(E, theta, S)
        
        F_threshold = 0.5
        intentional_mask = (F_grid < F_threshold).astype(int)
        
        labeled_array, num_features = label(intentional_mask)
        
        print(f"   Connected components: {num_features}")
        
        if num_features > 1:
            sizes = [np.sum(labeled_array == i) for i in range(1, num_features+1)]
            print(f"   Component sizes: {sizes}")
            
            main_component_size = max(sizes)
            total_size = sum(sizes)
            
            assert main_component_size > 0.8 * total_size, \
                f"Basin fragmented: main only {main_component_size/total_size:.1%}"
        
        print(f"\n✓ Basin connectivity: Simply connected")


def test_topology_summary():
    """Summary of topological analysis."""
    print("\n" + "="*60)
    print("LEVEL 3: TOPOLOGICAL ANALYSIS")
    print("="*60)
    print("✓ Morse theory: Single global minimum")
    print("✓ Gradient flow: Converges to low-E")
    print("✓ Basin structure: Simply connected")
    print("\nStatus: F has expected topological structure")
    print("="*60)
