"""
Phase 0: Theory Validation Suite

Hierarchical validation of adaptonic metrics implementation.

Levels:
0. Axioms (5s) - Basic properties
1. Fidelity (30s) - KERNEL correctness
2. Scaling (2min) - RG properties
3. Topology (5min) - Global structure

Run: pytest experiments/theory_validation/ -v
"""

__version__ = "0.1.0"
__status__ = "Phase 0 - Theory Validation"
