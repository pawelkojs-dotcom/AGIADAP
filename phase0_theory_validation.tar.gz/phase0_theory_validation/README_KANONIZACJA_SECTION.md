## Phase 0: Theory Validation Framework

Before deploying metrics to H_GEN_1 or AGI systems, we validate implementation fidelity through **4-level hierarchical testing**:

### Validation Hierarchy

#### Level 0: Axioms (< 5 sec, CI/CD)
Basic mathematical properties - bounds, limits, no NaN/Inf.  
**Status:** ✅ Required for all commits

#### Level 1: Fidelity (< 30 sec, Every PR)
Implementation correctness - σ,Θ,S,F match KERNEL_AGI definitions.  
**Status:** ✅ Required for all PRs

#### Level 2: Scaling (< 2 min, Pre-release)
RG properties - finite-size scaling, coarse-graining, critical exponents.  
**Status:** ✅ Required for releases

#### Level 3: Topology (< 5 min, Major versions)
Global structure - Morse theory, basin analysis, gradient flow.  
**Status:** ⚠️ Recommended for major versions

### Philosophy: Deductive Method

```
Theory (KERNEL_AGI) → Implementation (core/) → Validation (Phase 0) → Application (H_GEN_1)
```

NOT: Data → Pattern → Model

### Quick Start

```bash
# Fast validation (CI/CD)
pytest experiments/theory_validation/test_axioms.py -v

# Complete validation
./experiments/theory_validation/run_full_validation.sh
```

### When Phase 0 is Complete

✅ Level 0-1 all pass  
✅ Level 2 no numerical explosions  
✅ Level 3 topology confirmed  
→ **Decision Gate 1: GO to Phase 1 (H_GEN_1)**

**Documentation:** `experiments/theory_validation/00_README_PHASE0.md`

---
