# Phase 0 Theory Validation - Complete Package

## 📦 Package Contents

This package contains the complete **Phase 0: Deep Theory Validation** suite for Adaptonic AGI project.

**Philosophy:** Hybrid approach combining GPT's clarity with Claude's depth.

---

## 📁 File Structure

```
phase0_theory_validation/
├── MANIFEST.md                              # This file
├── README_KANONIZACJA_SECTION.md           # Section to add to main README
└── experiments/
    └── theory_validation/
        ├── 00_README_PHASE0.md             # Main documentation
        ├── __init__.py                     # Package marker
        ├── test_axioms.py                  # Level 0: < 5s
        ├── test_fidelity.py                # Level 1: < 30s
        ├── test_scaling.py                 # Level 2: < 2min
        ├── test_topology.py                # Level 3: < 5min
        ├── run_full_validation.sh          # Runner script
        ├── results/                        # Test outputs (created on run)
        └── visualizations/
            └── plot_phase_diagrams.py      # Visualization generator
```

---

## 🚀 Quick Start

### Step 1: Install Package (5 minutes)

```bash
# Copy to your project
cp -r experiments/ /path/to/your/adaptonic_project/

# OR: Install from current location
cd /path/to/your/adaptonic_project
export PYTHONPATH=$PYTHONPATH:/path/to/phase0_theory_validation
```

### Step 2: Verify Installation

```bash
# Test imports
python -c "from adaptonic_metrics.core.sigma import compute_sigma_spectral; print('✓ OK')"

# If import fails, install adaptonic_metrics:
pip install -e /path/to/adaptonic_metrics
```

### Step 3: Run Fast Tests (30 seconds)

```bash
cd /path/to/your/adaptonic_project

# Level 0 only
pytest experiments/theory_validation/test_axioms.py -v

# Level 0+1
pytest experiments/theory_validation/test_axioms.py experiments/theory_validation/test_fidelity.py -v
```

### Step 4: Full Validation (8 minutes)

```bash
# All levels + visualizations
./experiments/theory_validation/run_full_validation.sh

# Results in:
ls experiments/theory_validation/results/
```

---

## 📊 What Each Level Tests

### Level 0: Axioms (< 5 seconds)
**Purpose:** Catch obvious bugs  
**Tests:** Bounds [0,1], no NaN/Inf, type safety

**Example:**
```python
import numpy as np
from adaptonic_metrics.core.sigma import compute_sigma_spectral

X = np.random.randn(20, 30)
sigma = compute_sigma_spectral(X)
assert 0 <= sigma <= 1  # Must pass
```

---

### Level 1: Fidelity (< 30 seconds)
**Purpose:** Verify implementation matches KERNEL_AGI  
**Tests:** Limits, monotonicity, invariances

**Example:**
```python
# Perfect order: σ → 1
v = np.random.randn(64)
X = np.tile(v, (20, 1))
sigma = compute_sigma_spectral(X)
assert sigma > 0.95  # Should be ≈1
```

---

### Level 2: Scaling (< 2 minutes)
**Purpose:** RG properties, critical phenomena  
**Tests:** Finite-size scaling, coarse-graining

**Example:**
```python
# Coarse-graining: σ preserved
beliefs_fine = ...  # N=100 agents
beliefs_coarse = block_average(beliefs_fine, block_size=5)  # N=20

sigma_fine = compute_sigma_spectral(beliefs_fine)
sigma_coarse = compute_sigma_spectral(beliefs_coarse)
assert abs(sigma_fine - sigma_coarse) < 0.15
```

---

### Level 3: Topology (< 5 minutes)
**Purpose:** Global F landscape structure  
**Tests:** Critical points, basins, gradient flow

**Example:**
```python
# F should have single minimum at low E
F_grid = compute_F_landscape(E_range, theta_range, S_range)
minima = find_critical_points(F_grid, type='minimum')
assert len(minima) == 1
assert minima[0].E < 0.3
```

---

## 🎯 Decision Gate 1

After running full validation:

### ✅ GO to Phase 1 (H_GEN_1) if:
- All Level 0-1 tests pass
- Level 2 shows σ, S, Θ scale correctly (< 10% drift)
- Level 3 confirms F has single minimum at low E

### ⚠️ REVIEW if:
- Level 2-3 show unexpected behavior
- Computational complexity > expected (O(d³))
- Any Crisis #1-4 symptoms detected

### ❌ NO-GO (fix implementation) if:
- Any Level 0-1 test fails
- Metrics violate basic axioms
- NaN/Inf in normal operation

---

## 📖 Integration Guide

### Into Existing Project

1. **Copy files:**
   ```bash
   cp -r experiments/theory_validation /your/project/experiments/
   ```

2. **Update main README:**
   ```bash
   cat README_KANONIZACJA_SECTION.md >> /your/project/README.md
   ```

3. **Add to CI/CD:**
   ```yaml
   # .github/workflows/test.yml
   - name: Phase 0 Validation
     run: |
       pytest experiments/theory_validation/test_axioms.py -v
       pytest experiments/theory_validation/test_fidelity.py -v
   ```

---

## 🔧 Customization

### Adjust Thresholds

Edit test files to match your tolerances:

```python
# test_fidelity.py
def test_perfect_order_limit(self):
    assert sigma > 0.95  # ← Adjust if needed
```

### Add New Tests

```python
# test_fidelity.py

class TestSigmaFidelity:
    def test_my_new_property(self):
        """Test custom property."""
        # Your test here
        pass
```

---

## 📚 Documentation

### Main Documents
- `00_README_PHASE0.md` - Complete Phase 0 guide
- `THEORY_VALIDATION_PROTOCOL.md` - Methodology (in main project)
- `KERNEL_AGI.md` - Theoretical foundations (in main project)

### Test Documentation
Each test file has detailed docstrings:
```python
"""
Level 1: Implementation Fidelity Tests

Verify that core implementations faithfully realize KERNEL_AGI theory.
...
"""
```

---

## 🐛 Troubleshooting

### Import Errors

```bash
# Error: ModuleNotFoundError: No module named 'adaptonic_metrics'
# Solution:
pip install -e /path/to/adaptonic_metrics
# OR:
export PYTHONPATH=$PYTHONPATH:/path/to/adaptonic_metrics
```

### Test Failures

```bash
# If Level 0-1 fail:
# → Fix implementation in adaptonic_metrics/core/

# If Level 2-3 show issues:
# → Review but may proceed with caution
# → Document limitations
```

### Visualization Errors

```bash
# If matplotlib errors:
pip install matplotlib scipy

# If display issues:
export MPLBACKEND=Agg  # Non-interactive
```

---

## 📞 Support

For questions about:
- **Theory:** See KERNEL_AGI.md, INVARIANTS_AGI.md
- **Implementation:** See adaptonic_metrics/core/
- **Methodology:** See THEORY_VALIDATION_PROTOCOL.md

---

## ✅ Checklist

Before Phase 1 (H_GEN_1):

- [ ] All files copied to project
- [ ] Dependencies installed (numpy, scipy, matplotlib, pytest)
- [ ] Level 0 tests pass (< 5s)
- [ ] Level 1 tests pass (< 30s)
- [ ] Level 2 reviewed (< 2min)
- [ ] Level 3 documented (< 5min)
- [ ] Visualizations generated
- [ ] Decision Gate 1: GO/NO-GO documented

---

## 📜 License

Same as main Adaptonic AGI project.

---

## 🙏 Acknowledgments

**Hybrid approach:**
- GPT: Philosophy, documentation clarity
- Claude: Implementation depth, RG/topology

**Theory foundation:**
- KERNEL_AGI (Paweł's work)
- Wilson (1971): RG methods
- Landau (1937): Phase transitions
- Popper (1959): Deductive method

---

**Version:** 0.1.0  
**Status:** Phase 0 - Theory Validation  
**Date:** 2025-11-21
